from functools import lru_cache

from pydantic import field_validator
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    DATABASE_URL: str
    SECRET_KEY: str
    ENVIRONMENT: str = "development"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60
    CORS_ORIGINS: str = "http://localhost:3000,http://localhost:5173"

    @field_validator("SECRET_KEY")
    @classmethod
    def secret_key_is_strong_enough(cls, value: str) -> str:
        if len(value) < 32 or value.startswith("change-me"):
            raise ValueError("SECRET_KEY must be a unique secret of at least 32 characters")
        return value

    @field_validator("ENVIRONMENT")
    @classmethod
    def validate_environment(cls, value: str) -> str:
        if value not in {"development", "production"}:
            raise ValueError("ENVIRONMENT must be development or production")
        return value

    @property
    def cors_origins_list(self) -> list[str]:
        origins = [origin.strip() for origin in self.CORS_ORIGINS.split(",") if origin.strip()]
        if self.ENVIRONMENT == "production":
            if self.SECRET_KEY.startswith("dev-"):
                raise ValueError("Production requires a unique SECRET_KEY")
            if not origins or "*" in origins or any("localhost" in o for o in origins):
                raise ValueError("Production CORS_ORIGINS must contain explicit public origins")
        return origins

    model_config = {"env_file": ".env", "case_sensitive": True}


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
