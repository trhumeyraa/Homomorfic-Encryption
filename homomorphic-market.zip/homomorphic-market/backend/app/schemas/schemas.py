from pydantic import BaseModel, EmailStr, Field, field_validator
from typing import List


# ─── Auth Schemas ───────────────────────────────────────────────────────────

class InstitutionRegister(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    email: EmailStr
    password: str
    tax_number: str = Field(min_length=10, max_length=11)
    sector: str = Field(min_length=1, max_length=100)
    city: str = Field(min_length=1, max_length=100)

    model_config = {"str_strip_whitespace": True}

    @field_validator("password")
    @classmethod
    def password_strength(cls, v):
        if len(v) < 8:
            raise ValueError("Şifre en az 8 karakter olmalıdır")
        if len(v.encode("utf-8")) > 72:
            raise ValueError("Şifre bcrypt için en fazla 72 bayt olabilir")
        return v

    @field_validator("tax_number")
    @classmethod
    def tax_number_format(cls, v):
        if not v.isdigit() or len(v) not in [10, 11]:
            raise ValueError("Vergi numarası 10 veya 11 haneli olmalıdır")
        return v


class InstitutionLogin(BaseModel):
    email: EmailStr
    password: str

    @field_validator("password")
    @classmethod
    def bcrypt_password_limit(cls, value: str) -> str:
        if len(value.encode("utf-8")) > 72:
            raise ValueError("Şifre bcrypt için en fazla 72 bayt olabilir")
        return value


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    institution_name: str
    institution_id: int


# ─── Analytics Schemas ──────────────────────────────────────────────────────


class MonthlySummary(BaseModel):
    month: int
    year: int
    total_revenue: float
    total_quantity: int
    avg_price: float


class CategorySummary(BaseModel):
    category: str
    total_revenue: float
    total_quantity: int
    product_count: int
    avg_price: float


class DashboardSummary(BaseModel):
    total_revenue: float
    total_quantity: int
    avg_unit_price: float
    top_category: str
    top_product: str
    monthly_growth: float
    active_products: int
    revenue_change_percent: float
