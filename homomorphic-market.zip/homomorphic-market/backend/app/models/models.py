from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Boolean, Text
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.core.database import Base


class Institution(Base):
    __tablename__ = "institutions"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(200), nullable=False)
    email = Column(String(200), unique=True, index=True, nullable=False)
    hashed_password = Column(String(200), nullable=False)
    tax_number = Column(String(50), unique=True, nullable=False)
    sector = Column(String(100), nullable=False)
    city = Column(String(100), nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    sales = relationship("SaleRecord", back_populates="institution")


class SaleRecord(Base):
    __tablename__ = "sale_records"

    id = Column(Integer, primary_key=True, index=True)
    institution_id = Column(Integer, ForeignKey("institutions.id"), nullable=False, index=True)
    product_name = Column(String(200), nullable=False)
    category = Column(String(100), nullable=False)
    # Numeric sale values are stored only as CKKS ciphertexts below.
    sale_date = Column(DateTime(timezone=True), nullable=False, index=True)
    month = Column(Integer, nullable=False)
    year = Column(Integer, nullable=False)
    region = Column(String(100), nullable=False)

    # Şifreli veriler (TenSEAL ile şifrelenmiş, base64 olarak saklanır)
    encrypted_revenue  = Column(Text, nullable=False)
    encrypted_quantity = Column(Text, nullable=False)
    encrypted_price    = Column(Text, nullable=False)
    is_shared          = Column(Boolean, default=False)  # Rakiplerle paylaşıma açık mı

    institution = relationship("Institution", back_populates="sales")


class InstitutionKey(Base):
    """Her kurumun kendine ait CKKS anahtarları"""
    __tablename__ = "institution_keys"

    id = Column(Integer, primary_key=True, index=True)
    institution_id = Column(Integer, ForeignKey("institutions.id"), unique=True, nullable=False)
    # Public-only context (rakip hesaplamaları için sunucuda saklanır)
    public_context_b64 = Column(Text, nullable=False)
    # Wrapped secret context. The server uses it for owner analytics and its
    # disclosed centralized ranking demo over opted-in peer records.
    secret_context_b64 = Column(Text, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
