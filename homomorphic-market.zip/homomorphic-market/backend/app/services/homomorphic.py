"""
CKKS homomorphic encryption helpers.

Important boundary:
- Public contexts can encrypt data and evaluate ciphertext operations.
- Only contexts that include the secret key can decrypt evaluated results.
- Only a context containing the secret key can decrypt. The competitive demo
  uses the server-held peer secret contexts and is therefore a trusted-server flow.
"""
import base64
import hashlib
import hmac
import time
from typing import List, Optional, Tuple

import tenseal as ts
from cryptography.fernet import Fernet

from app.core.config import settings


POLY_MOD_DEGREE = 8192
COEFF_MOD_BITS = [60, 40, 40, 60]
GLOBAL_SCALE = 2 ** 40
SECRET_CONTEXT_PREFIX = "enc:v2:"
LEGACY_SECRET_CONTEXT_PREFIX = "enc:v1:"


def _fernet(legacy: bool = False) -> Fernet:
    secret = settings.SECRET_KEY.encode("utf-8")
    digest = hashlib.sha256(secret).digest() if legacy else hmac.new(
        secret,
        b"ciphermarket/secret-context/v2",
        hashlib.sha256,
    ).digest()
    return Fernet(base64.urlsafe_b64encode(digest))


def create_institution_context() -> ts.Context:
    """Create a CKKS context containing a secret key for one institution."""
    ctx = ts.context(
        ts.SCHEME_TYPE.CKKS,
        poly_modulus_degree=POLY_MOD_DEGREE,
        coeff_mod_bit_sizes=COEFF_MOD_BITS,
    )
    ctx.generate_galois_keys()
    ctx.global_scale = GLOBAL_SCALE
    return ctx


def serialize_context_with_secret(ctx: ts.Context) -> str:
    """Serialize full context. In this demo it is stored server-side for owner analytics."""
    return base64.b64encode(ctx.serialize(save_secret_key=True)).decode()


def protect_secret_context(serialized_b64: str) -> str:
    token = _fernet().encrypt(serialized_b64.encode("utf-8")).decode("utf-8")
    return f"{SECRET_CONTEXT_PREFIX}{token}"


def unprotect_secret_context(stored_value: str) -> str:
    if stored_value.startswith(SECRET_CONTEXT_PREFIX):
        prefix, fernet = SECRET_CONTEXT_PREFIX, _fernet()
    elif stored_value.startswith(LEGACY_SECRET_CONTEXT_PREFIX):
        prefix, fernet = LEGACY_SECRET_CONTEXT_PREFIX, _fernet(legacy=True)
    else:
        raise ValueError("Secret context is not protected with the configured application key")
    token = stored_value[len(prefix):]
    return fernet.decrypt(token.encode("utf-8")).decode("utf-8")


def serialize_context_public_only(ctx: ts.Context) -> str:
    """Serialize context without the secret key for encryption/evaluation."""
    ctx_copy = ts.context_from(ctx.serialize(save_secret_key=True))
    ctx_copy.make_context_public()
    return base64.b64encode(ctx_copy.serialize()).decode()


def load_context(serialized_b64: str) -> ts.Context:
    return ts.context_from(base64.b64decode(serialized_b64))


def load_secret_context(stored_value: str) -> ts.Context:
    return load_context(unprotect_secret_context(stored_value))


def encrypt_values(ctx: ts.Context, values: List[float]) -> str:
    vec = ts.ckks_vector(ctx, values)
    return base64.b64encode(vec.serialize()).decode()


def decrypt_values(secret_ctx: ts.Context, encrypted_b64: str) -> List[float]:
    vec = ts.ckks_vector_from(secret_ctx, base64.b64decode(encrypted_b64))
    return vec.decrypt()


def he_sum_encrypted(eval_ctx: ts.Context, encrypted_list: List[str]) -> Tuple[Optional[str], float]:
    """Return encrypted sum and elapsed ms. No decryption happens here."""
    if not encrypted_list:
        return None, 0.0

    t0 = time.time()
    total = None
    for enc_b64 in encrypted_list:
        vec = ts.ckks_vector_from(eval_ctx, base64.b64decode(enc_b64))
        scalar_sum = vec.sum()
        total = scalar_sum if total is None else total + scalar_sum

    elapsed = (time.time() - t0) * 1000
    if total is None:
        return None, elapsed
    return base64.b64encode(total.serialize()).decode(), elapsed


def decrypt_scalar(secret_ctx: ts.Context, encrypted_b64: Optional[str]) -> float:
    if not encrypted_b64:
        return 0.0
    vec = ts.ckks_vector_from(secret_ctx, base64.b64decode(encrypted_b64))
    return float(vec.decrypt()[0])


def he_sum_decrypt(secret_ctx: ts.Context, encrypted_list: List[str]) -> Tuple[float, float]:
    """Evaluate sum homomorphically, then decrypt with a secret-key context."""
    encrypted_sum, elapsed = he_sum_encrypted(secret_ctx, encrypted_list)
    return decrypt_scalar(secret_ctx, encrypted_sum), elapsed


def he_mean_decrypt(secret_ctx: ts.Context, encrypted_list: List[str]) -> Tuple[float, float]:
    if not encrypted_list:
        return 0.0, 0.0
    encrypted_sum, elapsed = he_sum_encrypted(secret_ctx, encrypted_list)
    mean_ciphertext = ts.ckks_vector_from(
        secret_ctx, base64.b64decode(encrypted_sum)
    ) * (1.0 / len(encrypted_list))
    started = time.perf_counter()
    value = float(mean_ciphertext.decrypt()[0])
    return value, elapsed + (time.perf_counter() - started) * 1000


def performance_comparison(secret_ctx: ts.Context, values: List[float]) -> dict:
    """Compare plaintext and CKKS evaluation for owner-authorized demo data."""
    results = {}

    t0 = time.perf_counter()
    plain_sum = sum(values)
    plain_sum_ms = (time.perf_counter() - t0) * 1000

    t0 = time.perf_counter()
    enc_b64 = encrypt_values(secret_ctx, values)
    vec = ts.ckks_vector_from(secret_ctx, base64.b64decode(enc_b64))
    he_result = vec.sum().decrypt()[0]
    he_sum_ms = (time.perf_counter() - t0) * 1000
    sum_ciphertext_bytes = len(base64.b64decode(enc_b64))

    results["sum"] = {
        "plain_result": round(plain_sum, 2),
        "encrypted_result": round(float(he_result), 2),
        "plain_time_ms": round(plain_sum_ms, 4),
        "encrypted_time_ms": round(he_sum_ms, 4),
        "overhead_factor": round(he_sum_ms / max(plain_sum_ms, 0.001), 2),
        "ciphertext_bytes": sum_ciphertext_bytes,
        "ciphertext_preview": f"{enc_b64[:18]}...{enc_b64[-10:]}",
    }

    t0 = time.perf_counter()
    plain_mean = sum(values) / len(values)
    plain_mean_ms = (time.perf_counter() - t0) * 1000

    t0 = time.perf_counter()
    enc_b64 = encrypt_values(secret_ctx, values)
    vec = ts.ckks_vector_from(secret_ctx, base64.b64decode(enc_b64))
    he_mean_val = (vec.sum() * (1.0 / len(values))).decrypt()[0]
    he_mean_ms = (time.perf_counter() - t0) * 1000
    mean_ciphertext_bytes = len(base64.b64decode(enc_b64))

    results["mean"] = {
        "plain_result": round(float(plain_mean), 2),
        "encrypted_result": round(float(he_mean_val), 2),
        "plain_time_ms": round(plain_mean_ms, 4),
        "encrypted_time_ms": round(he_mean_ms, 4),
        "overhead_factor": round(he_mean_ms / max(plain_mean_ms, 0.001), 2),
        "ciphertext_bytes": mean_ciphertext_bytes,
        "ciphertext_preview": f"{enc_b64[:18]}...{enc_b64[-10:]}",
    }

    return results
