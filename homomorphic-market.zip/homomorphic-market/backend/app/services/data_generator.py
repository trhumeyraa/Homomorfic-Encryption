import random
from datetime import datetime
from sqlalchemy.orm import Session
from app.models.models import InstitutionKey, SaleRecord
from app.services.homomorphic import encrypt_values, load_context

PRODUCTS = {
    "Gıda & İçecek": [
        ("Organik Süt 1L", 32.90),
        ("Tam Buğday Ekmek", 18.50),
        ("Zeytinyağı 750ml", 189.90),
        ("Makarna 500g", 24.90),
        ("Pirinç 1kg", 42.90),
        ("Domates Salçası", 28.50),
        ("Mısır Gevreği", 65.90),
        ("Hazır Çorba", 19.90),
        ("Meyve Suyu 1L", 38.90),
        ("Kahve 250g", 149.90),
    ],
    "Temizlik & Hijyen": [
        ("Çamaşır Deterjanı 3kg", 189.90),
        ("Bulaşık Deterjanı 750ml", 54.90),
        ("Tuvalet Kağıdı 32'li", 149.90),
        ("Sıvı El Sabunu 300ml", 34.90),
        ("Yer Temizleyici 1L", 45.90),
        ("Çöp Poşeti 50'li", 39.90),
        ("Cam Sileceği", 28.90),
        ("Yüz Maskesi 50'li", 89.90),
    ],
    "Kişisel Bakım": [
        ("Şampuan 400ml", 79.90),
        ("Diş Macunu 75ml", 34.90),
        ("Deodorant Roll-On", 54.90),
        ("Nemlendirici Krem 200ml", 129.90),
        ("Tıraş Jeli", 49.90),
        ("Saç Kremi 350ml", 89.90),
    ],
    "Elektronik Aksesuar": [
        ("USB Kablo 1m", 49.90),
        ("Şarj Adaptörü", 129.90),
        ("Kulaklık Seti", 299.90),
        ("Pil AA 4'lü", 39.90),
        ("Telefon Kılıfı", 89.90),
        ("Ekran Koruyucu", 59.90),
    ],
    "Ev & Yaşam": [
        ("Plastik Saklama Kabı Set", 79.90),
        ("Mutfak Havlusu 3'lü", 69.90),
        ("Mum Seti", 89.90),
        ("Çerçeve 13x18", 49.90),
        ("Paspas", 129.90),
        ("Yastık Kılıfı 2'li", 99.90),
    ],
    "Atıştırmalık": [
        ("Cips 120g", 34.90),
        ("Çikolata 100g", 44.90),
        ("Bisküvi 300g", 28.90),
        ("Kuruyemiş Karışım 200g", 79.90),
        ("Sakız 30'lu", 19.90),
        ("Gofret 50g", 14.90),
    ],
}

CITIES = ["İstanbul", "Ankara", "İzmir", "Bursa", "Antalya", "Konya", "Adana", "Gaziantep"]
REGIONS = ["Marmara", "İç Anadolu", "Ege", "Akdeniz", "Karadeniz", "Güneydoğu Anadolu", "Doğu Anadolu"]


def generate_sales_for_institution(
    db: Session,
    institution_id: int,
    months_back: int = 12,
    records_per_month: int = 80
):
    """Bir kurum için gerçekçi ve şifreli satış verisi üret"""
    key_rec = db.query(InstitutionKey).filter(
        InstitutionKey.institution_id == institution_id
    ).first()
    if not key_rec:
        raise ValueError("Kurum CKKS anahtarı bulunamadı")

    ctx = load_context(key_rec.public_context_b64)
    records = []
    now = datetime.now()

    for month_offset in range(months_back, 0, -1):
        month_index = now.year * 12 + (now.month - 1) - month_offset
        year, month_zero_based = divmod(month_index, 12)
        month = month_zero_based + 1

        # Mevsimsel çarpan (yaz ayları atıştırmalık artar, kış temizlik artar vb.)
        seasonal_boost = {
            "Gıda & İçecek": 1.0 + 0.1 * (1 if month in [6, 7, 8] else 0),
            "Temizlik & Hijyen": 1.0 + 0.2 * (1 if month in [12, 1, 2] else 0),
            "Kişisel Bakım": 1.0 + 0.15 * (1 if month in [3, 4, 5] else 0),
            "Elektronik Aksesuar": 1.0 + 0.3 * (1 if month in [11, 12] else 0),
            "Ev & Yaşam": 1.0 + 0.2 * (1 if month in [3, 4] else 0),
            "Atıştırmalık": 1.0 + 0.25 * (1 if month in [6, 7, 8] else 0),
        }

        for _ in range(records_per_month):
            category = random.choice(list(PRODUCTS.keys()))
            product_name, base_price = random.choice(PRODUCTS[category])

            # Fiyat dalgalanması (%±15)
            price = round(base_price * random.uniform(0.85, 1.15), 2)
            boost = seasonal_boost.get(category, 1.0)
            quantity = int(random.randint(10, 200) * boost)
            total = round(price * quantity, 2)

            sale_day = random.randint(1, 28)
            sale_date = datetime(year, month, sale_day)
            region = random.choice(REGIONS)

            records.append(SaleRecord(
                institution_id=institution_id,
                product_name=product_name,
                category=category,
                sale_date=sale_date,
                month=month,
                year=year,
                region=region,
                encrypted_revenue=encrypt_values(ctx, [total]),
                encrypted_quantity=encrypt_values(ctx, [float(quantity)]),
                encrypted_price=encrypt_values(ctx, [price]),
                is_shared=False,
            ))

    db.bulk_save_objects(records)
    db.commit()
    return len(records)
