from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.core.security import decode_token
from app.models.models import Institution

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")


def get_current_institution(
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(get_db)
) -> Institution:
    payload = decode_token(token)
    if not payload:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Geçersiz veya süresi dolmuş token",
            headers={"WWW-Authenticate": "Bearer"},
        )

    try:
        institution_id = int(payload.get("sub"))
    except (TypeError, ValueError):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Geçersiz token konusu",
            headers={"WWW-Authenticate": "Bearer"},
        )

    institution = db.query(Institution).filter(Institution.id == institution_id).first()

    if not institution or not institution.is_active:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Kullanıcı bulunamadı")

    return institution
