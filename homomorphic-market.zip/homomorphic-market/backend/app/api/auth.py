import logging
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.security import create_access_token, get_password_hash, verify_password
from app.models.models import Institution, InstitutionKey
from app.schemas.schemas import InstitutionLogin, InstitutionRegister, TokenResponse
from app.services.homomorphic import (
    create_institution_context,
    protect_secret_context,
    serialize_context_public_only,
    serialize_context_with_secret,
)

router = APIRouter(prefix="/auth", tags=["auth"])
logger = logging.getLogger(__name__)


@router.post("/register", response_model=dict, status_code=status.HTTP_201_CREATED)
def register(data: InstitutionRegister, db: Session = Depends(get_db)):
    if db.query(Institution).filter(Institution.email == data.email).first():
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Bu e-posta adresi zaten kayıtlı",
        )
    if db.query(Institution).filter(Institution.tax_number == data.tax_number).first():
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Bu vergi numarası zaten kayıtlı",
        )

    try:
        ctx = create_institution_context()
        institution = Institution(
            name=data.name,
            email=data.email,
            hashed_password=get_password_hash(data.password),
            tax_number=data.tax_number,
            sector=data.sector,
            city=data.city,
        )
        db.add(institution)
        db.flush()

        key_record = InstitutionKey(
            institution_id=institution.id,
            secret_context_b64=protect_secret_context(serialize_context_with_secret(ctx)),
            public_context_b64=serialize_context_public_only(ctx),
        )
        db.add(key_record)
        db.commit()
        db.refresh(institution)
    except Exception:
        logger.exception("Registration failed while creating the account or CKKS context")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Kayıt tamamlanamadı. Sunucu günlüklerini kontrol edin.",
        )

    return {
        "message": "Kayıt başarılı. CKKS anahtarlarınız oluşturuldu.",
        "institution_id": institution.id,
        "he_keys_generated": True,
    }


@router.post("/login", response_model=TokenResponse)
def login(data: InstitutionLogin, db: Session = Depends(get_db)):
    institution = db.query(Institution).filter(Institution.email == data.email).first()
    if not institution or not verify_password(data.password, institution.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="E-posta veya şifre hatalı",
        )
    if not institution.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Hesabınız askıya alınmış",
        )

    token = create_access_token({"sub": str(institution.id), "email": institution.email})
    return TokenResponse(
        access_token=token,
        institution_name=institution.name,
        institution_id=institution.id,
    )
