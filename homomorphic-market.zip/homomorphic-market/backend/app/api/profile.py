from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel, EmailStr, Field, field_validator
from typing import Optional
from app.core.database import get_db
from app.core.security import verify_password, get_password_hash
from app.api.deps import get_current_institution
from app.models.models import Institution, InstitutionKey, SaleRecord
from sqlalchemy import func

router = APIRouter(prefix="/profile", tags=["profile"])

SECTORS = [
    'Gıda Perakende','Süpermarket Zinciri','Market & Bakkal',
    'Elektronik & Teknoloji','Bilgisayar & Yazılım','Telefon & Aksesuar',
    'Tekstil & Giyim','Ayakkabı & Çanta','Spor Giyim',
    'Ev & Yaşam','Mobilya & Dekorasyon','Yapı Market & Hırdavat',
    'Kozmetik & Kişisel Bakım','Eczane & Sağlık',
    'Spor & Outdoor','Oyuncak & Hobi',
    'Otomotiv Yan Sanayi','Yedek Parça',
    'Kitap & Kırtasiye','Ofis Malzemeleri',
    'Restoran & Kafe','Pastane & Fırın',
    'İnşaat & Taahhüt','Tarım & Hayvancılık',
    'Lojistik & Nakliye','Turizm & Otelcilik',
    'Eğitim & Özel Kurs','Finans & Sigorta',
    'Medya & Reklam','Diğer'
]

CITIES = [
    'Adana','Adıyaman','Afyonkarahisar','Ağrı','Amasya','Ankara','Antalya','Artvin',
    'Aydın','Balıkesir','Bilecik','Bingöl','Bitlis','Bolu','Burdur','Bursa',
    'Çanakkale','Çankırı','Çorum','Denizli','Diyarbakır','Edirne','Elazığ','Erzincan',
    'Erzurum','Eskişehir','Gaziantep','Giresun','Gümüşhane','Hakkari','Hatay','Isparta',
    'Mersin','İstanbul','İzmir','Kars','Kastamonu','Kayseri','Kırklareli','Kırşehir',
    'Kocaeli','Konya','Kütahya','Malatya','Manisa','Kahramanmaraş','Mardin','Muğla',
    'Muş','Nevşehir','Niğde','Ordu','Rize','Sakarya','Samsun','Siirt','Sinop',
    'Sivas','Tekirdağ','Tokat','Trabzon','Tunceli','Şanlıurfa','Uşak','Van',
    'Yozgat','Zonguldak','Aksaray','Bayburt','Karaman','Kırıkkale','Batman','Şırnak',
    'Bartın','Ardahan','Iğdır','Yalova','Karabük','Kilis','Osmaniye','Düzce'
]

class ProfileUpdate(BaseModel):
    name: Optional[str] = None
    sector: Optional[str] = None
    city: Optional[str] = None

class PasswordChange(BaseModel):
    current_password: str = Field(max_length=72)
    new_password: str = Field(min_length=8)

    @field_validator("new_password")
    @classmethod
    def bcrypt_password_limit(cls, value: str) -> str:
        if len(value.encode("utf-8")) > 72:
            raise ValueError("Şifre bcrypt için en fazla 72 bayt olabilir")
        return value

@router.get("/me")
def get_profile(
    institution: Institution = Depends(get_current_institution),
    db: Session = Depends(get_db)
):
    key_rec = db.query(InstitutionKey).filter(
        InstitutionKey.institution_id == institution.id).first()

    record_count = db.query(func.count(SaleRecord.id)).filter(
        SaleRecord.institution_id == institution.id).scalar() or 0

    return {
        "id": institution.id,
        "name": institution.name,
        "email": institution.email,
        "tax_number": institution.tax_number,
        "sector": institution.sector,
        "city": institution.city,
        "is_active": institution.is_active,
        "created_at": institution.created_at.isoformat() if institution.created_at else None,
        "he_keys_ready": key_rec is not None,
        "he_scheme": "CKKS",
        "he_library": "TenSEAL 0.3.18",
        "total_records": record_count,
        "sectors": SECTORS,
        "cities": CITIES,
    }

@router.put("/update")
def update_profile(
    data: ProfileUpdate,
    institution: Institution = Depends(get_current_institution),
    db: Session = Depends(get_db)
):
    if data.name:
        institution.name = data.name
    if data.sector and data.sector in SECTORS:
        institution.sector = data.sector
    if data.city and data.city in CITIES:
        institution.city = data.city
    db.commit()
    db.refresh(institution)
    return {"message": "Profil güncellendi", "name": institution.name,
            "sector": institution.sector, "city": institution.city}

@router.put("/change-password")
def change_password(
    data: PasswordChange,
    institution: Institution = Depends(get_current_institution),
    db: Session = Depends(get_db)
):
    if not verify_password(data.current_password, institution.hashed_password):
        raise HTTPException(status_code=400, detail="Mevcut şifre yanlış")
    institution.hashed_password = get_password_hash(data.new_password)
    db.commit()
    return {"message": "Şifre başarıyla güncellendi"}
