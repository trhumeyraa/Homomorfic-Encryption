"""Data entry endpoints; numeric fields are encrypted before persistence."""
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Query
from sqlalchemy.orm import Session
from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime
import base64
import csv, io
import math
import logging

from app.core.database import get_db
from app.api.deps import get_current_institution
from app.models.models import Institution, SaleRecord, InstitutionKey
from app.services.homomorphic import decrypt_scalar, load_context, load_secret_context, encrypt_values

router = APIRouter(prefix="/data", tags=["data-entry"])
logger = logging.getLogger(__name__)
MAX_CSV_BYTES = 2 * 1024 * 1024
MAX_CSV_ROWS = 5000

VALID_CATEGORIES = [
    'Gıda & İçecek','Temizlik & Hijyen','Kişisel Bakım',
    'Elektronik Aksesuar','Ev & Yaşam','Atıştırmalık',
    'Tekstil & Giyim','Spor & Outdoor','Oyuncak & Hobi','Diğer'
]


def _get_public_ctx(institution_id: int, db: Session):
    key_rec = db.query(InstitutionKey).filter(
        InstitutionKey.institution_id == institution_id).first()
    if not key_rec:
        raise HTTPException(status_code=500, detail="Kurum anahtarı bulunamadı")
    return load_context(key_rec.public_context_b64)


class SaleEntryRequest(BaseModel):
    product_name: str = Field(min_length=1, max_length=200)
    category: str = Field(min_length=1, max_length=100)
    quantity_sold: int = Field(gt=0, le=1_000_000)
    unit_price: float = Field(gt=0, le=10_000_000)
    sale_date: str
    region: Optional[str] = Field(default="Diğer", max_length=100)


@router.post("/entry/manual")
def add_manual_sale(
    data: SaleEntryRequest,
    institution: Institution = Depends(get_current_institution),
    db: Session = Depends(get_db)
):
    try:
        sale_date = datetime.strptime(data.sale_date, "%Y-%m-%d")
    except ValueError:
        raise HTTPException(status_code=400, detail="Tarih formatı YYYY-MM-DD olmalıdır")
    if not math.isfinite(data.unit_price):
        raise HTTPException(status_code=400, detail="Birim fiyat sonlu bir sayı olmalıdır")
    if data.quantity_sold <= 0 or data.unit_price <= 0:
        raise HTTPException(status_code=400, detail="Adet ve birim fiyat pozitif olmalıdır")

    total_revenue = round(data.unit_price * data.quantity_sold, 2)
    ctx = _get_public_ctx(institution.id, db)

    # The API receives plaintext; encrypt it before writing to the database.
    enc_revenue  = encrypt_values(ctx, [total_revenue])
    enc_quantity = encrypt_values(ctx, [float(data.quantity_sold)])
    enc_price    = encrypt_values(ctx, [data.unit_price])
    encrypted_bytes = base64.b64decode(enc_revenue)

    record = SaleRecord(
        institution_id=institution.id,
        product_name=data.product_name,
        category=data.category if data.category in VALID_CATEGORIES else 'Diğer',
        sale_date=sale_date,
        month=sale_date.month,
        year=sale_date.year,
        region=data.region or 'Diğer',
        encrypted_revenue=enc_revenue,
        encrypted_quantity=enc_quantity,
        encrypted_price=enc_price,
    )
    db.add(record)
    db.commit()
    db.refresh(record)

    return {
        "message": "Satış kaydı homomorfik şifrelendi ve kaydedildi",
        "record_id": record.id,
        "encrypted": True,
        "scheme": "CKKS",
        "raw_data_stored": False,
        "ciphertext_preview": enc_revenue[:72] + "…",
        "ciphertext_size_bytes": len(encrypted_bytes),
    }


@router.post("/entry/csv")
async def upload_csv(
    file: UploadFile = File(...),
    institution: Institution = Depends(get_current_institution),
    db: Session = Depends(get_db)
):
    if not file.filename or not file.filename.casefold().endswith('.csv'):
        raise HTTPException(status_code=400, detail="Yalnızca CSV dosyası kabul edilir")

    content = await file.read(MAX_CSV_BYTES + 1)
    await file.close()
    if len(content) > MAX_CSV_BYTES:
        raise HTTPException(status_code=413, detail="CSV dosyası en fazla 2 MB olabilir")
    try:
        decoded = content.decode('utf-8-sig')
    except UnicodeDecodeError:
        decoded = content.decode('latin-1')

    reader = csv.DictReader(io.StringIO(decoded))
    required = {'product_name', 'category', 'quantity_sold', 'unit_price', 'sale_date'}
    if not reader.fieldnames or not required.issubset(set(reader.fieldnames)):
        raise HTTPException(status_code=400,
            detail=f"CSV kolonları eksik. Gerekli: {', '.join(required)}")

    ctx = _get_public_ctx(institution.id, db)
    records, errors = [], []

    for i, row in enumerate(reader, 1):
        if i > MAX_CSV_ROWS:
            errors.append(f"En fazla {MAX_CSV_ROWS} satır yüklenebilir")
            break
        try:
            product_name = (row.get('product_name') or '').strip()
            if not product_name or len(product_name) > 200:
                raise ValueError("Ürün adı 1-200 karakter olmalıdır")
            sale_date = datetime.strptime((row.get('sale_date') or '').strip(), "%Y-%m-%d")
            qty   = int(row['quantity_sold'])
            price = float(row['unit_price'])
            if not math.isfinite(price) or qty <= 0 or qty > 1_000_000 or price <= 0 or price > 10_000_000:
                raise ValueError("Adet ve birim fiyat pozitif olmalıdır")
            total = round(price * qty, 2)
            cat   = row['category'].strip()
            if cat not in VALID_CATEGORIES:
                cat = 'Diğer'
            region = (row.get('region') or 'Diğer').strip()
            if not region or len(region) > 100:
                raise ValueError("Bölge 1-100 karakter olmalıdır")

            records.append(SaleRecord(
                institution_id=institution.id,
                product_name=product_name,
                category=cat,
                sale_date=sale_date, month=sale_date.month, year=sale_date.year,
                region=region,
                encrypted_revenue=encrypt_values(ctx, [total]),
                encrypted_quantity=encrypt_values(ctx, [float(qty)]),
                encrypted_price=encrypt_values(ctx, [price]),
            ))
        except Exception as e:
            errors.append(f"Satır {i}: {str(e)}")

    if records:
        db.bulk_save_objects(records)
        db.commit()

    return {
        "message": f"{len(records)} kayıt homomorfik şifrelendi ve kaydedildi",
        "inserted": len(records),
        "errors": errors[:10],
        "raw_data_stored": False,
        "scheme": "CKKS",
    }


@router.get("/entries")
def list_entries(
    limit: int = Query(default=50, ge=1, le=200),
    institution: Institution = Depends(get_current_institution),
    db: Session = Depends(get_db)
):
    """Girişleri listele — şifreli değerleri çözerek göster (sadece yetkili kurum)"""
    key_rec = db.query(InstitutionKey).filter(
        InstitutionKey.institution_id == institution.id).first()
    if not key_rec:
        return []

    # Secret key ile context yükle (sadece kendi verilerini açabilir)
    ctx = load_secret_context(key_rec.secret_context_b64)

    rows = db.query(SaleRecord).filter(
        SaleRecord.institution_id == institution.id
    ).order_by(SaleRecord.sale_date.desc()).limit(limit).all()

    result = []
    for r in rows:
        try:
            rev_val = round(decrypt_scalar(ctx, r.encrypted_revenue), 2)
            qty_val = round(decrypt_scalar(ctx, r.encrypted_quantity))
            price_val = round(decrypt_scalar(ctx, r.encrypted_price), 2)
        except Exception as exc:
            logger.exception("Unable to decrypt an institution-owned sale entry")
            raise HTTPException(status_code=500, detail="Kayıt çözümlenemedi; listeleme tamamlanamadı") from exc

        result.append({
            "id": r.id,
            "product_name": r.product_name,
            "category": r.category,
            "quantity_sold": qty_val,
            "unit_price": price_val,
            "total_revenue": rev_val,
            "sale_date": r.sale_date.strftime("%Y-%m-%d"),
            "region": r.region,
            "is_shared": r.is_shared,
            "encrypted": True,
            "decrypted_by_server_for_owner": True,
        })
    return result


@router.get("/categories")
def get_categories():
    return VALID_CATEGORIES


@router.put("/share/{record_id}")
def toggle_share(
    record_id: int,
    institution: Institution = Depends(get_current_institution),
    db: Session = Depends(get_db)
):
    """Kaydı rakiplerle paylaşıma aç/kapat"""
    record = db.query(SaleRecord).filter(
        SaleRecord.id == record_id,
        SaleRecord.institution_id == institution.id
    ).first()
    if not record:
        raise HTTPException(status_code=404, detail="Kayıt bulunamadı")
    record.is_shared = not record.is_shared
    db.commit()
    return {"record_id": record_id, "is_shared": record.is_shared}


@router.put("/share-all")
def share_all(
    institution: Institution = Depends(get_current_institution),
    db: Session = Depends(get_db)
):
    """Tüm kayıtları paylaşıma aç"""
    db.query(SaleRecord).filter(
        SaleRecord.institution_id == institution.id
    ).update({"is_shared": True})
    db.commit()
    return {"message": "Tüm veriler paylaşıma açıldı"}

