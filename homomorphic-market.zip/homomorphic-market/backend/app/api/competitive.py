"""
Competitive analytics.

This prototype evaluates per-institution ciphertext aggregates, then decrypts
shared peer aggregates on the application server to calculate a rank. The rank
and index are derived from plaintext inside that trusted server boundary. This
is not cross-institution homomorphic ranking or confidential aggregation.
"""
import base64
from collections import defaultdict
from typing import Optional
import logging

import tenseal as ts
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app.api.deps import get_current_institution
from app.core.database import get_db
from app.models.models import Institution, InstitutionKey, SaleRecord
from app.services.homomorphic import (
    decrypt_scalar,
    he_sum_decrypt,
    he_sum_encrypted,
    load_context,
    load_secret_context,
)

router = APIRouter(prefix="/competitive", tags=["competitive"])
logger = logging.getLogger(__name__)


def _enc_values(rows, field: str):
    return [getattr(r, field) for r in rows if getattr(r, field, None)]


def _owner_sum(secret_ctx, rows, field: str) -> float:
    try:
        value, _ = he_sum_decrypt(secret_ctx, _enc_values(rows, field))
        return max(value, 0.0)
    except Exception as exc:
        logger.exception("Unable to evaluate a shared encrypted aggregate")
        raise HTTPException(status_code=500, detail="Paylaşılan şifreli toplam çözümlenemedi") from exc


def _rank_score(secret_ctx, rows) -> tuple[float, float]:
    """Demo score computed by decrypting records on the application server."""
    revenue = _owner_sum(secret_ctx, rows, "encrypted_revenue")
    quantity = _owner_sum(secret_ctx, rows, "encrypted_quantity")
    return revenue, quantity


@router.get("/sector-comparison")
def sector_comparison(
    city: Optional[str] = Query(default=None),
    institution: Institution = Depends(get_current_institution),
    db: Session = Depends(get_db),
):
    available_cities = [
        row[0] for row in db.query(Institution.city).filter(
            Institution.sector == institution.sector,
            Institution.is_active == True,
        ).distinct().order_by(Institution.city).all()
    ]
    selected_city = city or institution.city

    peers_query = db.query(Institution).filter(
        Institution.sector == institution.sector,
        Institution.is_active == True,
    )
    if selected_city != "all":
        peers_query = peers_query.filter(Institution.city == selected_city)
    peers = peers_query.all()

    if institution.id not in {peer.id for peer in peers}:
        peers.append(institution)

    if not peers:
        peers = [institution]

    results = []
    for peer in peers:
        is_self = peer.id == institution.id
        key_rec = db.query(InstitutionKey).filter(
            InstitutionKey.institution_id == peer.id
        ).first()
        rows_query = db.query(SaleRecord).filter(SaleRecord.institution_id == peer.id)
        if not is_self:
            rows_query = rows_query.filter(SaleRecord.is_shared == True)
        rows = rows_query.all()

        cat_counts = defaultdict(int)
        for r in rows:
            cat_counts[r.category] += 1
        top_cat = max(cat_counts, key=cat_counts.get) if cat_counts else "-"

        base = {
            "institution_id": peer.id,
            "display_name": peer.name if is_self else f"Rakip #{peer.id}",
            "is_self": is_self,
            "sector": peer.sector,
            "city": peer.city,
            "top_category": top_cat,
            "has_data": len(rows) > 0,
            "shared_record_count": len(rows),
            "rank": None,
            "ranking_available": True,
            "ranking_score": 0,
            "ranking_metric": "trusted_aggregate_revenue_index",
            "ranking_demo": True,
            "encryption_details": {
                "scheme": "CKKS",
                "library": "TenSEAL 0.3.18",
                "raw_data_returned_to_requester": False,
                "server_decrypts_for_ranking": True,
                "key_type": "per_institution",
                "computed_on": "ciphertext_then_server_decryption",
                "ranking_protocol": "centralized_trusted_server_demo",
            },
        }

        if not key_rec or not rows:
            results.append({
                **base,
                "total_revenue": 0.0 if is_self else None,
                "total_quantity": 0 if is_self else None,
                "_rank_revenue": 0.0,
                "_rank_quantity": 0.0,
                "ciphertext_eval_ms": 0.0,
                "monthly_trend": [],
                "encrypted_only": not is_self,
                "encrypted_aggregate_size": 0,
            })
            continue

        if is_self:
            secret_ctx = load_secret_context(key_rec.secret_context_b64)
            total_rev = _owner_sum(secret_ctx, rows, "encrypted_revenue")
            total_qty = _owner_sum(secret_ctx, rows, "encrypted_quantity")

            monthly = defaultdict(float)
            monthly_qty = defaultdict(float)
            for r in rows:
                k = (r.year, r.month)
                monthly[k] += decrypt_scalar(secret_ctx, r.encrypted_revenue)
                monthly_qty[k] += decrypt_scalar(secret_ctx, r.encrypted_quantity)

            monthly_trend_sorted = sorted(
                [
                    {
                        "year": y,
                        "month": m,
                        "revenue": round(v, 2),
                        "quantity": int(round(monthly_qty[(y, m)])),
                    }
                    for (y, m), v in monthly.items()
                ],
                key=lambda x: (x["year"], x["month"]),
            )
            results.append({
                **base,
                "total_revenue": round(total_rev, 2),
                "total_quantity": int(round(total_qty)),
                "_rank_revenue": float(total_rev),
                "_rank_quantity": float(total_qty),
                "ciphertext_eval_ms": 0.0,
                "monthly_trend": monthly_trend_sorted,
                "encrypted_only": False,
                "encrypted_aggregate_size": 0,
            })
        else:
            public_ctx = load_context(key_rec.public_context_b64)
            enc_sum, he_ms = he_sum_encrypted(public_ctx, _enc_values(rows, "encrypted_revenue"))
            secret_ctx = load_secret_context(key_rec.secret_context_b64)
            rank_revenue, rank_quantity = _rank_score(secret_ctx, rows)
            monthly_trend = []
            grouped = defaultdict(list)
            for r in rows:
                grouped[(r.year, r.month)].append(r)
            for (year, month), month_rows in sorted(grouped.items()):
                enc_month, _ = he_sum_encrypted(public_ctx, _enc_values(month_rows, "encrypted_revenue"))
                monthly_trend.append({
                    "year": year,
                    "month": month,
                    "revenue": None,
                    "quantity": None,
                    "encrypted": enc_month is not None,
                })

            results.append({
                **base,
                "total_revenue": None,
                "total_quantity": None,
                "_rank_revenue": float(rank_revenue),
                "_rank_quantity": float(rank_quantity),
                "ciphertext_eval_ms": round(he_ms, 2),
                "monthly_trend": monthly_trend,
                "encrypted_only": True,
                "encrypted_aggregate_size": len(base64.b64decode(enc_sum)) if enc_sum else 0,
            })

    ranked = sorted(
        [r for r in results if r.get("has_data")],
        key=lambda r: (r.get("_rank_revenue", 0.0), r.get("_rank_quantity", 0.0)),
        reverse=True,
    )
    max_score = max([r.get("_rank_revenue", 0.0) for r in ranked] or [0.0])
    for idx, item in enumerate(ranked, 1):
        item["rank"] = idx
        item["ranking_score"] = round((item.get("_rank_revenue", 0.0) / max_score) * 100, 1) if max_score else 0

    my_rank = next((r["rank"] for r in results if r["is_self"]), None)
    for item in results:
        item.pop("_rank_revenue", None)
        item.pop("_rank_quantity", None)

    results.sort(key=lambda r: (r["rank"] is None, r["rank"] or 9999, not r["is_self"], r["display_name"]))
    return {
        "sector": institution.sector,
        "city": selected_city,
        "selected_city": selected_city,
        "available_cities": available_cities,
        "total_competitors": len([r for r in results if not r["is_self"]]),
        "my_rank": my_rank,
        "ranking_available": bool(ranked),
        "trusted_aggregation_demo": True,
        "ranking_method": "centralized_server_side_decryption",
        "ranking_confidentiality": False,
        "ranking_metric": "Sunucuda çözülen paylaşımlı gelir toplamlarından türetilen 0-100 endeks",
        "ranking_note": (
            "Sıralama için uygulama sunucusu paylaşıma açılmış rakip kayıtlarının "
            "şifreli toplamlarını kendi sakladığı kurum anahtarlarıyla çözer. Ham "
            "tutarlar API yanıtında gösterilmez; ancak sunucu bunları görür ve sıra "
            "bilgisi göreli gelir bilgisini sızdırır. Bu özellik HE ile gizli sıralama "
            "değildir. Gizli sıralama için ayrı bir MPC, çoklu anahtarlı HE veya "
            "güvenilir toplayıcı protokolü gerekir."
        ),
        "results": results,
    }


@router.get("/he-check")
def he_check(
    institution: Institution = Depends(get_current_institution),
    db: Session = Depends(get_db),
):
    key_rec = db.query(InstitutionKey).filter(
        InstitutionKey.institution_id == institution.id
    ).first()
    if not key_rec:
        return {"error": "Anahtar bulunamadı"}

    rows = db.query(SaleRecord).filter(
        SaleRecord.institution_id == institution.id,
        SaleRecord.encrypted_revenue != None,
    ).limit(5).all()
    if not rows:
        return {"verification": "no_data", "samples": [], "message": "Henüz veri yok"}

    secret_ctx = load_secret_context(key_rec.secret_context_b64)
    public_ctx = load_context(key_rec.public_context_b64)
    samples = []
    for r in rows:
        try:
            enc_bytes = base64.b64decode(r.encrypted_revenue)
            decrypted = ts.ckks_vector_from(secret_ctx, enc_bytes).decrypt()[0]
            evaluated = ts.ckks_vector_from(public_ctx, enc_bytes).sum()
            he_result = ts.ckks_vector_from(secret_ctx, evaluated.serialize()).decrypt()[0]
            samples.append({
                "record_id": r.id,
                "product": r.product_name,
                "decrypted_by_server_for_owner": round(float(decrypted), 2),
                "he_operation_result": round(float(he_result), 2),
                "values_match": abs(decrypted - he_result) < max(0.01, abs(decrypted) * 1e-6),
                "encrypted_size_bytes": len(enc_bytes),
                "ciphertext_to_float_ratio": round(len(enc_bytes) / 8, 1),
            })
        except Exception:
            logger.exception("Unable to verify ciphertext sample %s", r.id)
            samples.append({"record_id": r.id, "error": "Doğrulama başarısız oldu"})

    passed = [s for s in samples if s.get("values_match", False)]
    return {
        "verification": "passed" if len(passed) == len(samples) else "partial",
        "scheme": "CKKS",
        "key_management": "per_institution",
        "poly_modulus_degree": 8192,
        "global_scale": "2^40",
        "plain_data_in_db": False,
        "note": "Uygulama sunucusu kurum secret context'lerini SECRET_KEY ile koruyarak saklar; sunucu yöneticisi veriyi çözebilir.",
        "samples": samples,
        "message": (
            "Sayısal satış alanları CKKS ciphertext olarak saklanır. Bu demo "
            "backend kendi sakladığı secret context ile örnek sonucu çözüp karşılaştırır; bu üçüncü taraf doğrulanabilir kriptografik kanıt değildir."
        ),
    }
