"""
Analytics API.

Owner analytics use the institution secret context to decrypt authorized results.
The market aggregate endpoint evaluates opted-in peer ciphertexts with public
contexts. The separate competitive ranking demo decrypts peer data server-side.
"""
import base64
from collections import defaultdict
from datetime import datetime
from typing import List
import logging

import tenseal as ts
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.api.deps import get_current_institution
from app.core.database import get_db
from app.models.models import Institution, InstitutionKey, SaleRecord
from app.schemas.schemas import CategorySummary, DashboardSummary, MonthlySummary
from app.services.homomorphic import (
    decrypt_scalar,
    he_sum_decrypt,
    he_sum_encrypted,
    load_context,
    load_secret_context,
    performance_comparison,
)

router = APIRouter(prefix="/analytics", tags=["analytics"])
logger = logging.getLogger(__name__)


def _get_ctx(institution_id: int, db: Session, secret: bool = True) -> ts.Context | None:
    key_rec = db.query(InstitutionKey).filter(
        InstitutionKey.institution_id == institution_id
    ).first()
    if not key_rec:
        return None
    return load_secret_context(key_rec.secret_context_b64) if secret else load_context(key_rec.public_context_b64)


def _enc_values(rows, field: str) -> List[str]:
    return [getattr(r, field) for r in rows if getattr(r, field, None)]


def _dec(secret_ctx: ts.Context | None, b64_str: str | None) -> float:
    if not secret_ctx or not b64_str:
        raise HTTPException(status_code=500, detail="Kurum anahtarı veya şifreli kayıt eksik")
    try:
        return decrypt_scalar(secret_ctx, b64_str)
    except Exception as exc:
        logger.exception("Unable to decrypt or evaluate encrypted analytics data")
        raise HTTPException(status_code=500, detail="Şifreli analiz verisi çözümlenemedi") from exc


def _owner_he_sum(secret_ctx: ts.Context | None, rows, field: str) -> float:
    if not secret_ctx:
        raise HTTPException(status_code=500, detail="Kurum secret context'i yüklenemedi")
    try:
        result, _ = he_sum_decrypt(secret_ctx, _enc_values(rows, field))
        return result
    except Exception as exc:
        logger.exception("Unable to decrypt or evaluate encrypted analytics data")
        raise HTTPException(status_code=500, detail="Şifreli analiz verisi çözümlenemedi") from exc


@router.get("/dashboard", response_model=DashboardSummary)
def get_dashboard(
    institution: Institution = Depends(get_current_institution),
    db: Session = Depends(get_db),
):
    rows = db.query(SaleRecord).filter(SaleRecord.institution_id == institution.id).all()
    if not rows:
        return DashboardSummary(
            total_revenue=0,
            total_quantity=0,
            avg_unit_price=0,
            top_category="-",
            top_product="-",
            monthly_growth=0,
            active_products=0,
            revenue_change_percent=0,
        )

    ctx = _get_ctx(institution.id, db, secret=True)
    total_revenue = _owner_he_sum(ctx, rows, "encrypted_revenue")
    total_quantity = _owner_he_sum(ctx, rows, "encrypted_quantity")
    total_price = _owner_he_sum(ctx, rows, "encrypted_price")
    avg_price = total_price / len(rows) if rows else 0

    cat_rev = defaultdict(float)
    prod_rev = defaultdict(float)
    for r in rows:
        rev = _dec(ctx, r.encrypted_revenue)
        cat_rev[r.category] += rev
        prod_rev[r.product_name] += rev

    now = datetime.now()
    prev_m = now.month - 1 if now.month > 1 else 12
    prev_y = now.year if now.month > 1 else now.year - 1
    curr_rows = [r for r in rows if r.month == now.month and r.year == now.year]
    prev_rows = [r for r in rows if r.month == prev_m and r.year == prev_y]
    curr_rev = _owner_he_sum(ctx, curr_rows, "encrypted_revenue")
    prev_rev = _owner_he_sum(ctx, prev_rows, "encrypted_revenue")
    growth = ((curr_rev - prev_rev) / prev_rev * 100) if prev_rev else 0

    return DashboardSummary(
        total_revenue=round(total_revenue, 2),
        total_quantity=int(round(total_quantity)),
        avg_unit_price=round(avg_price, 2),
        top_category=max(cat_rev, key=cat_rev.get) if cat_rev else "-",
        top_product=max(prod_rev, key=prod_rev.get) if prod_rev else "-",
        monthly_growth=round(growth, 2),
        active_products=len(set(r.product_name for r in rows)),
        revenue_change_percent=round(growth, 2),
    )


@router.get("/monthly", response_model=List[MonthlySummary])
def get_monthly(
    institution: Institution = Depends(get_current_institution),
    db: Session = Depends(get_db),
):
    rows = db.query(SaleRecord).filter(SaleRecord.institution_id == institution.id).all()
    if not rows:
        return []

    ctx = _get_ctx(institution.id, db, secret=True)
    monthly = defaultdict(lambda: {"revenue": 0.0, "quantity": 0.0, "price_sum": 0.0, "count": 0})
    for r in rows:
        key = (r.year, r.month)
        monthly[key]["revenue"] += _dec(ctx, r.encrypted_revenue)
        monthly[key]["quantity"] += _dec(ctx, r.encrypted_quantity)
        monthly[key]["price_sum"] += _dec(ctx, r.encrypted_price)
        monthly[key]["count"] += 1

    return [
        MonthlySummary(
            month=month,
            year=year,
            total_revenue=round(v["revenue"], 2),
            total_quantity=int(round(v["quantity"])),
            avg_price=round(v["price_sum"] / v["count"], 2) if v["count"] else 0,
        )
        for (year, month), v in sorted(monthly.items())
    ]


@router.get("/categories", response_model=List[CategorySummary])
def get_categories(
    institution: Institution = Depends(get_current_institution),
    db: Session = Depends(get_db),
):
    rows = db.query(SaleRecord).filter(SaleRecord.institution_id == institution.id).all()
    if not rows:
        return []

    ctx = _get_ctx(institution.id, db, secret=True)
    cats = defaultdict(lambda: {"revenue": 0.0, "quantity": 0.0, "products": set(), "price_sum": 0.0, "count": 0})
    for r in rows:
        c = cats[r.category]
        c["revenue"] += _dec(ctx, r.encrypted_revenue)
        c["quantity"] += _dec(ctx, r.encrypted_quantity)
        c["price_sum"] += _dec(ctx, r.encrypted_price)
        c["count"] += 1
        c["products"].add(r.product_name)

    return sorted(
        [
            CategorySummary(
                category=cat,
                total_revenue=round(v["revenue"], 2),
                total_quantity=int(round(v["quantity"])),
                product_count=len(v["products"]),
                avg_price=round(v["price_sum"] / v["count"], 2) if v["count"] else 0,
            )
            for cat, v in cats.items()
        ],
        key=lambda x: x.total_revenue,
        reverse=True,
    )


@router.get("/products/top")
def get_top_products(
    limit: int = 10,
    institution: Institution = Depends(get_current_institution),
    db: Session = Depends(get_db),
):
    rows = db.query(SaleRecord).filter(SaleRecord.institution_id == institution.id).all()
    if not rows:
        return []

    ctx = _get_ctx(institution.id, db, secret=True)
    prods = defaultdict(lambda: {"revenue": 0.0, "quantity": 0.0, "price_sum": 0.0, "count": 0, "category": ""})
    for r in rows:
        p = prods[r.product_name]
        p["revenue"] += _dec(ctx, r.encrypted_revenue)
        p["quantity"] += _dec(ctx, r.encrypted_quantity)
        p["price_sum"] += _dec(ctx, r.encrypted_price)
        p["count"] += 1
        p["category"] = r.category

    return [
        {
            "product_name": name,
            "category": v["category"],
            "total_revenue": round(v["revenue"], 2),
            "total_quantity": int(round(v["quantity"])),
            "avg_price": round(v["price_sum"] / v["count"], 2) if v["count"] else 0,
        }
        for name, v in sorted(prods.items(), key=lambda x: x[1]["revenue"], reverse=True)[:limit]
    ]


@router.get("/regional")
def get_regional(
    institution: Institution = Depends(get_current_institution),
    db: Session = Depends(get_db),
):
    rows = db.query(SaleRecord).filter(SaleRecord.institution_id == institution.id).all()
    if not rows:
        return []

    ctx = _get_ctx(institution.id, db, secret=True)
    regions = defaultdict(lambda: {"revenue": 0.0, "quantity": 0.0})
    for r in rows:
        regions[r.region]["revenue"] += _dec(ctx, r.encrypted_revenue)
        regions[r.region]["quantity"] += _dec(ctx, r.encrypted_quantity)

    return sorted(
        [
            {
                "region": reg,
                "total_revenue": round(v["revenue"], 2),
                "total_quantity": int(round(v["quantity"])),
            }
            for reg, v in regions.items()
        ],
        key=lambda x: x["total_revenue"],
        reverse=True,
    )


@router.get("/seasonal")
def get_seasonal(
    institution: Institution = Depends(get_current_institution),
    db: Session = Depends(get_db),
):
    rows = db.query(SaleRecord).filter(SaleRecord.institution_id == institution.id).all()
    if not rows:
        return []

    ctx = _get_ctx(institution.id, db, secret=True)
    season_map = {
        12: "Kış", 1: "Kış", 2: "Kış",
        3: "İlkbahar", 4: "İlkbahar", 5: "İlkbahar",
        6: "Yaz", 7: "Yaz", 8: "Yaz",
        9: "Sonbahar", 10: "Sonbahar", 11: "Sonbahar",
    }
    seasonal = defaultdict(lambda: {"revenue": 0.0, "quantity": 0.0})
    for r in rows:
        s = season_map[r.month]
        seasonal[s]["revenue"] += _dec(ctx, r.encrypted_revenue)
        seasonal[s]["quantity"] += _dec(ctx, r.encrypted_quantity)

    return [
        {
            "season": s,
            "total_revenue": round(v["revenue"], 2),
            "total_quantity": int(round(v["quantity"])),
        }
        for s, v in seasonal.items()
    ]


@router.get("/market-comparison")
def get_market_comparison(
    institution: Institution = Depends(get_current_institution),
    db: Session = Depends(get_db),
):
    institutions = db.query(Institution).filter(Institution.is_active == True).all()
    result = []
    for inst in institutions:
        is_self = inst.id == institution.id
        rows = db.query(SaleRecord).filter(
            SaleRecord.institution_id == inst.id,
            SaleRecord.is_shared == True if not is_self else True,
        ).all()
        key_rec = db.query(InstitutionKey).filter(InstitutionKey.institution_id == inst.id).first()
        if not key_rec:
            continue

        display_name = inst.name if is_self else f"Kurum #{inst.id}"
        top_cat = "-"
        if rows:
            cat_counts = defaultdict(int)
            for r in rows:
                cat_counts[r.category] += 1
            top_cat = max(cat_counts, key=cat_counts.get)

        if is_self:
            secret_ctx = load_secret_context(key_rec.secret_context_b64)
            total_rev = _owner_he_sum(secret_ctx, rows, "encrypted_revenue")
            total_qty = _owner_he_sum(secret_ctx, rows, "encrypted_quantity")
            result.append({
                "institution_name": display_name,
                "is_self": True,
                "sector": inst.sector,
                "city": inst.city,
                "total_revenue": round(total_rev, 2),
                "total_quantity": int(round(total_qty)),
                "top_category": top_cat,
                "he_computed": True,
                "encrypted_only": False,
            })
        else:
            public_ctx = load_context(key_rec.public_context_b64)
            enc_sum, he_ms = he_sum_encrypted(public_ctx, _enc_values(rows, "encrypted_revenue"))
            result.append({
                "institution_name": display_name,
                "is_self": False,
                "sector": inst.sector,
                "city": inst.city,
                "total_revenue": None,
                "total_quantity": None,
                "top_category": top_cat,
                "he_computed": enc_sum is not None,
                "encrypted_only": True,
                "shared_record_count": len(rows),
                "encrypted_aggregate_size": len(base64.b64decode(enc_sum)) if enc_sum else 0,
                "he_computation_ms": round(he_ms, 2),
            })

    return sorted(result, key=lambda x: (not x["is_self"], x["institution_name"]))


@router.get("/homomorphic/demo")
def homomorphic_demo(
    institution: Institution = Depends(get_current_institution),
    db: Session = Depends(get_db),
):
    rows = db.query(SaleRecord).filter(SaleRecord.institution_id == institution.id).limit(50).all()
    if not rows:
        return {"error": "Henüz veri yok", "hint": "Veri Girişi sekmesinden satış verisi ekleyin"}

    ctx = _get_ctx(institution.id, db, secret=True)
    values = [_dec(ctx, r.encrypted_revenue) for r in rows if r.encrypted_revenue]
    if not values:
        return {"error": "Şifreli veri bulunamadı"}

    return {
        "data_points": len(values),
        "operations": performance_comparison(ctx, values),
        "raw_data_in_db": False,
        "explanation": {
            "tr": "Tek çalıştırmalık demo; backend değerleri şifreler, CKKS toplama/ortalama işlemini yürütür ve secret context ile sonucu çözer. Bu performans benchmark'ı değildir."
        },
    }
