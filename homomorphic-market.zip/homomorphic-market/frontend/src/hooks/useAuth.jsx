import { createContext, useContext, useState, useEffect } from 'react'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const token = sessionStorage.getItem('token')
    const name  = sessionStorage.getItem('institution_name')
    const id    = sessionStorage.getItem('institution_id')
    if (token && name) setUser({ token, name, id })
    setLoading(false)
  }, [])

  const login = (data) => {
    sessionStorage.setItem('token', data.access_token)
    sessionStorage.setItem('institution_name', data.institution_name)
    sessionStorage.setItem('institution_id', data.institution_id)
    setUser({ token: data.access_token, name: data.institution_name, id: data.institution_id })
  }

  const logout = () => {
    sessionStorage.clear()
    setUser(null)
  }

  return (
    <AuthContext.Provider value={{ user, login, logout, loading }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => useContext(AuthContext)
