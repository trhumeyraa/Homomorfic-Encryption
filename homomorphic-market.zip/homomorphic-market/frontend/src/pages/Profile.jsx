import { useState, useEffect } from 'react'
import { User, Building2, MapPin, Shield, Key, CheckCircle2, AlertCircle, Edit3, Save, X } from 'lucide-react'
import api from '../utils/api.js'
import { useAuth } from '../hooks/useAuth.jsx'

const SECTORS = [
  'Gıda Perakende','Süpermarket Zinciri','Market & Bakkal',
  'Elektronik & Teknoloji','Bilgisayar & Yazılım','Telefon & Aksesuar',
  'Tekstil & Giyim','Ayakkabı & Çanta','Spor Giyim',
  'Ev & Yaşam','Mobilya & Dekorasyon','Yapı Market & Hırdavat',
  'Kozmetik & Kişisel Bakım','Eczane & Sağlık','Spor & Outdoor','Oyuncak & Hobi',
  'Otomotiv Yan Sanayi','Yedek Parça','Kitap & Kırtasiye','Ofis Malzemeleri',
  'Restoran & Kafe','Pastane & Fırın','İnşaat & Taahhüt','Tarım & Hayvancılık',
  'Lojistik & Nakliye','Turizm & Otelcilik','Eğitim & Özel Kurs','Finans & Sigorta',
  'Medya & Reklam','Diğer'
]
const CITIES = [
  'Adana','Adıyaman','Afyonkarahisar','Ağrı','Amasya','Ankara','Antalya','Artvin',
  'Aydın','Balıkesir','Bilecik','Bingöl','Bitlis','Bolu','Burdur','Bursa',
  'Çanakkale','Çankırı','Çorum','Denizli','Diyarbakır','Edirne','Elazığ','Erzincan',
  'Erzurum','Eskişehir','Gaziantep','Giresun','Gümüşhane','Hakkari','Hatay','Isparta',
  'Mersin','İstanbul','İzmir','Kars','Kastamonu','Kayseri','Kırklareli','Kırşehir',
  'Kocaeli','Konya','Kütahya','Malatya','Manisa','Kahramanmaraş','Mardin','Muğla',
  'Muş','Nevşehir','Niğde','Ordu','Rize','Sakarya','Samsun','Siirt','Sinop',
  'Sivas','Tekirdağ','Tokat','Trabzon','Tunceli','Şanlıurfa','Uşak','Van',
  'Yozgat','Zonguldak','Aksaray','Bayburt','Karaman','Kırıkkale','Batman','Şırnak',
  'Bartın','Ardahan','Iğdır','Yalova','Karabük','Kilis','Osmaniye','Düzce'
]

export default function Profile() {
  const { user } = useAuth()
  const [profile, setProfile] = useState(null)
  const [editing, setEditing]   = useState(false)
  const [form, setForm]         = useState({})
  const [pwForm, setPwForm]     = useState({ current_password:'', new_password:'' })
  const [msg, setMsg]           = useState(null)
  const [err, setErr]           = useState('')
  const [busy, setBusy]         = useState(false)
  const [pwBusy, setPwBusy]     = useState(false)

  useEffect(() => {
    api.get('/profile/me').then(r => {
      setProfile(r.data)
      setForm({ name: r.data.name, sector: r.data.sector, city: r.data.city })
    })
  }, [user?.id])

  const saveProfile = async () => {
    setBusy(true); setErr(''); setMsg(null)
    try {
      const { data } = await api.put('/profile/update', form)
      setProfile(p => ({ ...p, ...data }))
      setMsg('Profil güncellendi')
      setEditing(false)
    } catch(e) { setErr(e.response?.data?.detail || 'Hata') }
    finally { setBusy(false) }
  }

  const changePassword = async e => {
    e.preventDefault()
    setPwBusy(true); setErr(''); setMsg(null)
    try {
      await api.put('/profile/change-password', pwForm)
      setMsg('Şifre güncellendi')
      setPwForm({ current_password:'', new_password:'' })
    } catch(e) { setErr(e.response?.data?.detail || 'Hata') }
    finally { setPwBusy(false) }
  }

  if (!profile) return (
    <div className="flex items-center justify-center h-48">
      <div className="w-7 h-7 border-2 border-sapphire-500 border-t-transparent rounded-full animate-spin" />
    </div>
  )

  return (
    <div className="space-y-6 fade-in max-w-3xl">

      {msg && <div className="flex items-center gap-2 p-3 rounded-lg bg-sapphire-500/10 border border-sapphire-500/20 text-sapphire-400 text-sm"><CheckCircle2 size={14}/>{msg}</div>}
      {err && <div className="flex items-center gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-sm"><AlertCircle size={14}/>{err}</div>}

      {/* Kurum Bilgileri */}
      <div className="bg-ink-900 border border-white/6 rounded-2xl p-6">
        <div className="flex items-center justify-between mb-5">
          <h3 className="font-display font-600 text-white text-base flex items-center gap-2">
            <Building2 size={16} className="text-sapphire-400"/> Kurum Bilgileri
          </h3>
          {!editing ? (
            <button onClick={() => setEditing(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-slate-400 hover:text-white border border-white/10 hover:border-white/20 rounded-lg transition-colors">
              <Edit3 size={12}/> Düzenle
            </button>
          ) : (
            <div className="flex gap-2">
              <button onClick={saveProfile} disabled={busy}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs bg-sapphire-500 hover:bg-sapphire-400 text-white rounded-lg transition-colors">
                <Save size={12}/> {busy ? 'Kaydediliyor…' : 'Kaydet'}
              </button>
              <button onClick={() => setEditing(false)}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs border border-white/10 text-slate-400 hover:text-white rounded-lg transition-colors">
                <X size={12}/> İptal
              </button>
            </div>
          )}
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs text-slate-500 mb-1.5 uppercase tracking-wider">Kurum Adı</label>
            {editing ? (
              <input value={form.name} onChange={e => setForm(f=>({...f,name:e.target.value}))}
                className="w-full px-4 py-3 bg-ink-800 border border-white/10 focus:border-sapphire-500/60 rounded-xl text-white text-sm outline-none transition-colors"/>
            ) : (
              <p className="text-white font-medium">{profile.name}</p>
            )}
          </div>
          <div>
            <label className="block text-xs text-slate-500 mb-1.5 uppercase tracking-wider">E-posta</label>
            <p className="text-slate-400 text-sm">{profile.email}</p>
          </div>
          <div>
            <label className="block text-xs text-slate-500 mb-1.5 uppercase tracking-wider">Vergi Numarası</label>
            <p className="text-slate-400 text-sm font-mono">{profile.tax_number}</p>
          </div>
          <div>
            <label className="block text-xs text-slate-500 mb-1.5 uppercase tracking-wider">Kayıt Tarihi</label>
            <p className="text-slate-400 text-sm">{profile.created_at ? new Date(profile.created_at).toLocaleDateString('tr-TR') : '-'}</p>
          </div>
          <div>
            <label className="block text-xs text-slate-500 mb-1.5 uppercase tracking-wider">Sektör</label>
            {editing ? (
              <select value={form.sector} onChange={e => setForm(f=>({...f,sector:e.target.value}))}
                className="w-full px-4 py-3 bg-ink-800 border border-white/10 focus:border-sapphire-500/60 rounded-xl text-white text-sm outline-none">
                {SECTORS.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            ) : (
              <p className="text-white text-sm">{profile.sector}</p>
            )}
          </div>
          <div>
            <label className="block text-xs text-slate-500 mb-1.5 uppercase tracking-wider">Şehir</label>
            {editing ? (
              <select value={form.city} onChange={e => setForm(f=>({...f,city:e.target.value}))}
                className="w-full px-4 py-3 bg-ink-800 border border-white/10 focus:border-sapphire-500/60 rounded-xl text-white text-sm outline-none">
                {CITIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            ) : (
              <p className="text-white text-sm">{profile.city}</p>
            )}
          </div>
        </div>
      </div>

      {/* HE Güvenlik Durumu */}
      <div className="bg-ink-900 border border-white/6 rounded-2xl p-6">
        <h3 className="font-display font-600 text-white text-base flex items-center gap-2 mb-5">
          <Shield size={16} className="text-sapphire-400"/> Homomorfik Şifreleme Durumu
        </h3>
        <div className="grid md:grid-cols-3 gap-4">
          <div className="p-4 rounded-xl bg-sapphire-500/10 border border-sapphire-500/20">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-2 h-2 rounded-full bg-sapphire-400 pulse-dot"/>
              <span className="text-xs text-sapphire-400 font-medium">CKKS Anahtarları</span>
            </div>
            <p className="text-white font-medium text-sm">{profile.he_keys_ready ? 'Aktif ✓' : 'Oluşturulmamış'}</p>
            <p className="text-xs text-slate-500 mt-0.5">Kurum bazlı per-key</p>
          </div>
          <div className="p-4 rounded-xl bg-ink-800/50 border border-white/6">
            <p className="text-xs text-slate-500 mb-1">Şifreleme Şeması</p>
            <p className="font-mono text-white text-sm">{profile.he_scheme}</p>
            <p className="text-xs text-slate-500 mt-0.5">{profile.he_library}</p>
          </div>
          <div className="p-4 rounded-xl bg-ink-800/50 border border-white/6">
            <p className="text-xs text-slate-500 mb-1">Toplam Kayıt</p>
            <p className="font-display text-2xl text-white font-700">{profile.total_records}</p>
            <p className="text-xs text-slate-500 mt-0.5">şifreli satış kaydı</p>
          </div>
        </div>
      </div>

      {/* Şifre Değiştir */}
      <div className="bg-ink-900 border border-white/6 rounded-2xl p-6">
        <h3 className="font-display font-600 text-white text-base flex items-center gap-2 mb-5">
          <Key size={16} className="text-sapphire-400"/> Şifre Değiştir
        </h3>
        <form onSubmit={changePassword} className="space-y-4 max-w-md">
          <div>
            <label className="block text-xs text-slate-500 mb-1.5 uppercase tracking-wider">Mevcut Şifre</label>
            <input type="password" value={pwForm.current_password}
              onChange={e => setPwForm(f=>({...f,current_password:e.target.value}))} required
              className="w-full px-4 py-3 bg-ink-800 border border-white/10 focus:border-sapphire-500/60 rounded-xl text-white text-sm outline-none transition-colors"/>
          </div>
          <div>
            <label className="block text-xs text-slate-500 mb-1.5 uppercase tracking-wider">Yeni Şifre</label>
            <input type="password" value={pwForm.new_password}
              onChange={e => setPwForm(f=>({...f,new_password:e.target.value}))} required
              placeholder="En az 8 karakter"
              className="w-full px-4 py-3 bg-ink-800 border border-white/10 focus:border-sapphire-500/60 rounded-xl text-white text-sm outline-none transition-colors placeholder-slate-600"/>
          </div>
          <button type="submit" disabled={pwBusy}
            className="px-6 py-2.5 bg-sapphire-500 hover:bg-sapphire-400 disabled:opacity-50 text-white rounded-xl text-sm font-medium transition-colors">
            {pwBusy ? 'Güncelleniyor…' : 'Şifreyi Güncelle'}
          </button>
        </form>
      </div>
    </div>
  )
}
