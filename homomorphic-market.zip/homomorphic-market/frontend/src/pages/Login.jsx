import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Database, Eye, EyeOff, AlertCircle } from 'lucide-react'
import { useAuth } from '../hooks/useAuth.jsx'
import api from '../utils/api.js'

export default function Login() {
  const { login } = useAuth()
  const navigate  = useNavigate()
  const [form, setForm]   = useState({ email:'', password:'' })
  const [show, setShow]   = useState(false)
  const [error, setError] = useState('')
  const [busy, setBusy]   = useState(false)

  const handle = e => setForm(f => ({ ...f, [e.target.name]: e.target.value }))

  const submit = async e => {
    e.preventDefault(); setError(''); setBusy(true)
    try {
      const { data } = await api.post('/auth/login', form)
      login(data); navigate('/dashboard')
    } catch(err) { setError(err.response?.data?.detail || 'Giriş başarısız') }
    finally { setBusy(false) }
  }

  return (
    <div className="min-h-screen bg-ink-950 flex">
      {/* Left panel */}
      <div className="hidden lg:flex lg:w-5/12 relative bg-ink-900 border-r border-white/5 items-center justify-center p-16 overflow-hidden">
        <div className="absolute inset-0 bg-grid-fine bg-grid-fine opacity-100" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 bg-sapphire-600/8 rounded-full blur-3xl" />
        <div className="relative text-center">
          <div className="w-14 h-14 rounded-2xl bg-sapphire-600/15 border border-sapphire-600/25 flex items-center justify-center mx-auto mb-6">
            <Database size={24} className="text-sapphire-400" />
          </div>
          <h2 className="font-bold text-xl text-white mb-2 tracking-tight">CipherMarket</h2>
          <p className="text-slate-500 text-sm leading-relaxed max-w-xs">
            CKKS destekli pazar analitiği prototipi. Sayısal alanlar veritabanına yazılmadan önce şifrelenir; uygulama sunucusu anahtarları da tutar.
          </p>
          <div className="mt-8 space-y-2 text-left">
            {['CKKS ile sayıların DB’de şifrelenmesi','Sunucuda tutulan kurum anahtarları','Açık metadata alanları','Merkezi demo sıralaması'].map(t => (
              <div key={t} className="flex items-center gap-2 text-xs text-slate-500">
                <div className="w-1 h-1 rounded-full bg-sapphire-400 flex-shrink-0" />
                {t}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right panel */}
      <div className="flex-1 flex items-center justify-center px-6 py-12">
        <div className="w-full max-w-sm fade-up">
          <Link to="/" className="flex items-center gap-2 mb-10 lg:hidden">
            <div className="w-6 h-6 rounded-lg bg-sapphire-600 flex items-center justify-center">
              <Database size={12} className="text-white" />
            </div>
            <span className="font-semibold text-white text-sm">CipherMarket</span>
          </Link>

          <div className="mb-8">
            <h1 className="font-bold text-2xl text-white mb-1 tracking-tight">Giriş Yap</h1>
            <p className="text-slate-500 text-sm">Kurumsal hesabınızla devam edin</p>
          </div>

          {error && (
            <div className="mb-5 flex items-center gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/15 text-red-400 text-sm">
              <AlertCircle size={14} className="flex-shrink-0" /> {error}
            </div>
          )}

          <form onSubmit={submit} className="space-y-4">
            <div>
              <label className="block text-xs text-slate-500 mb-1.5 font-medium uppercase tracking-wider">E-posta</label>
              <input name="email" type="email" value={form.email} onChange={handle} required
                placeholder="kurum@sirket.com"
                className="input w-full px-4 py-2.5" />
            </div>
            <div>
              <label className="block text-xs text-slate-500 mb-1.5 font-medium uppercase tracking-wider">Şifre</label>
              <div className="relative">
                <input name="password" type={show ? 'text' : 'password'} value={form.password} onChange={handle} required
                  placeholder="••••••••"
                  className="input w-full px-4 py-2.5 pr-10" />
                <button type="button" onClick={() => setShow(s => !s)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-600 hover:text-slate-400 transition-colors">
                  {show ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </div>
            <button type="submit" disabled={busy}
              className="btn-primary w-full py-2.5 text-sm mt-1">
              {busy ? (
                <span className="flex items-center justify-center gap-2">
                  <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Giriş yapılıyor…
                </span>
              ) : 'Giriş Yap'}
            </button>
          </form>

          <p className="mt-6 text-center text-sm text-slate-600">
            Hesabınız yok mu?{' '}
            <Link to="/register" className="text-sapphire-400 hover:text-sapphire-300 font-medium transition-colors">
              Kayıt olun
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}
