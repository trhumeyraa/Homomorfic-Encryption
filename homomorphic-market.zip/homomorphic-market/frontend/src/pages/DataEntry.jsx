import { useState, useRef, useEffect, useCallback } from 'react'
import { PlusCircle, Upload, CheckCircle2, AlertCircle, Lock, Trash2, Share2, RefreshCw } from 'lucide-react'
import api from '../utils/api.js'

const CATEGORIES = [
  'Gıda & İçecek','Temizlik & Hijyen','Kişisel Bakım',
  'Elektronik Aksesuar','Ev & Yaşam','Atıştırmalık',
  'Tekstil & Giyim','Spor & Outdoor','Oyuncak & Hobi','Diğer'
]
const REGIONS = ['Marmara','İç Anadolu','Ege','Akdeniz','Karadeniz','Güneydoğu Anadolu','Doğu Anadolu']
const today = () => new Date().toISOString().split('T')[0]
const fmt   = n => new Intl.NumberFormat('tr-TR',{style:'currency',currency:'TRY',maximumFractionDigits:0}).format(n)

function CipherText({ preview, sizeBytes }) {
  return (
    <div className="mt-3 p-3 rounded-xl bg-ink-950 border border-sapphire-500/20">
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs text-sapphire-400 flex items-center gap-1 font-mono"><Lock size={10}/> CKKS Şifreli Çıktı</span>
        <span className="text-xs text-slate-500">Gerçek ciphertext · {sizeBytes} bayt</span>
      </div>
      <p className="font-mono text-xs text-slate-400 break-all leading-relaxed">{preview}</p>
    </div>
  )
}

function ShareModal({ record, onConfirm, onCancel }) {
  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-ink-900 border border-white/10 rounded-2xl p-6 max-w-md w-full shadow-2xl fade-up">
        <div className="w-10 h-10 rounded-xl bg-sapphire-500/20 border border-sapphire-500/30 flex items-center justify-center mb-4">
          <Share2 size={18} className="text-sapphire-400"/>
        </div>
        <h3 className="font-display font-600 text-white text-lg mb-2">Veriyi Rakiplerle Paylaş?</h3>
        <p className="text-slate-400 text-sm mb-4 leading-relaxed">
          <span className="text-white font-medium">"{record.product_name}"</span> kaydınız rakip kurumlarla paylaşılsın mı?
        </p>
        <div className="p-3 rounded-xl bg-ink-800/50 border border-white/6 text-xs text-slate-400 mb-5 space-y-1.5">
          <p className="flex items-center gap-1.5"><Lock size={10} className="text-sapphire-400"/> Diğer kurumların API yanıtında ham tutar gösterilmez</p>
          <p className="flex items-center gap-1.5"><AlertCircle size={10} className="text-amber-400"/> Sunucu, demo sıralamasını hesaplarken paylaşılan değerleri çözer</p>
          <p className="flex items-center gap-1.5"><AlertCircle size={10} className="text-amber-400"/> Sıra ve endeks göreli gelir bilgisi açığa çıkarabilir</p>
        </div>
        <div className="flex gap-3">
          <button type="button" onClick={onConfirm}
            className="flex-1 py-2.5 bg-sapphire-500 hover:bg-sapphire-400 text-white rounded-xl text-sm font-medium transition-colors flex items-center justify-center gap-2">
            <Share2 size={13}/> Evet, Paylaş
          </button>
          <button type="button" onClick={onCancel}
            className="flex-1 py-2.5 border border-white/10 text-slate-400 hover:text-white rounded-xl text-sm transition-colors">
            Şimdilik Hayır
          </button>
        </div>
      </div>
    </div>
  )
}

export default function DataEntry() {
  const [tab, setTab]               = useState('manual')
  const [form, setForm]             = useState({ product_name:'', category:'', quantity_sold:'', unit_price:'', sale_date:today(), region:'Marmara' })
  const [busy, setBusy]             = useState(false)
  const [lastRecord, setLastRecord] = useState(null)   // en son eklenen kayıt (şifreli gösterim için)
  const [error, setError]           = useState('')
  const [csvFile, setCsvFile]       = useState(null)
  const [csvResult, setCsvResult]   = useState(null)
  const [shareQueue, setShareQueue] = useState([])     // paylaşım bekleyen kayıtlar kuyruğu
  const [entries, setEntries]       = useState([])
  const [entriesLoading, setEntriesLoading] = useState(false)
  const fileRef = useRef()

  const handle = e => setForm(f => ({ ...f, [e.target.name]: e.target.value }))

  const loadEntries = useCallback(async () => {
    setEntriesLoading(true)
    try {
      const { data } = await api.get('/data/entries?limit=30')
      setEntries(data)
    } catch {}
    finally { setEntriesLoading(false) }
  }, [])

  useEffect(() => { loadEntries() }, [loadEntries])

  // Kuyrukta bekleyen paylaşım varsa modal göster
  const currentShareItem = shareQueue.length > 0 ? shareQueue[0] : null

  const handleShare = async (recordId, doShare) => {
    if (doShare) {
      try { await api.put(`/data/share/${recordId}`) } catch {}
    }
    // Kuyruktan çıkar
    setShareQueue(q => q.slice(1))
    loadEntries()
  }

  const submitManual = async e => {
    e.preventDefault()
    setError(''); setLastRecord(null); setBusy(true)
    try {
      const payload = {
        ...form,
        quantity_sold: parseInt(form.quantity_sold),
        unit_price: parseFloat(form.unit_price),
      }
      const { data } = await api.post('/data/entry/manual', payload)
      const rec = {
        record_id: data.record_id,
        ciphertext_preview: data.ciphertext_preview,
        ciphertext_size_bytes: data.ciphertext_size_bytes,
        product_name: form.product_name,
        category: form.category,
        total_revenue: parseFloat(form.unit_price) * parseInt(form.quantity_sold),
      }
      setLastRecord(rec)
      setForm(f => ({ ...f, product_name:'', quantity_sold:'', unit_price:'' }))
      loadEntries()
      // Her kayıt için kuyruğa ekle
      setTimeout(() => setShareQueue(q => [...q, rec]), 700)
    } catch(err) {
      setError(err.response?.data?.detail || 'Kayıt eklenemedi')
    } finally { setBusy(false) }
  }

  const submitCSV = async () => {
    if (!csvFile) return
    setBusy(true); setCsvResult(null); setError('')
    const fd = new FormData()
    fd.append('file', csvFile)
    try {
      const { data } = await api.post('/data/entry/csv', fd, { headers:{'Content-Type':'multipart/form-data'} })
      setCsvResult(data)
      setCsvFile(null)
      if (fileRef.current) fileRef.current.value = ''
      loadEntries()
    } catch(err) {
      setError(err.response?.data?.detail || 'CSV yüklenemedi')
    } finally { setBusy(false) }
  }

  const toggleShare = async (id) => {
    try { await api.put(`/data/share/${id}`) } catch {}
    loadEntries()
  }

  return (
    <div className="space-y-6 fade-in">

      {/* Paylaşım modal kuyruğu */}
      {currentShareItem && (
        <ShareModal
          record={currentShareItem}
          onConfirm={() => handleShare(currentShareItem.record_id, true)}
          onCancel={() => handleShare(currentShareItem.record_id, false)}
        />
      )}

      {/* HE banner */}
      <div className="flex items-center gap-3 p-4 rounded-2xl bg-sapphire-500/10 border border-sapphire-500/20">
        <div className="w-9 h-9 rounded-xl bg-sapphire-500/20 flex items-center justify-center flex-shrink-0">
          <Lock size={16} className="text-sapphire-400"/>
        </div>
        <div>
          <p className="text-sm font-medium text-sapphire-300">Homomorfik Şifreleme Aktif — CKKS</p>
          <p className="text-xs text-slate-400">Sayısal alanlar ciphertext olarak saklanır; ürün, kategori, tarih ve bölge metadata'sı açık kalır. Demo sunucusu kurum anahtarlarını da tutar.</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-ink-800 rounded-xl w-fit">
        {[['manual','Manuel Giriş'],['csv','CSV Yükle'],['list','Kayıtlar']].map(([k,l]) => (
          <button key={k} onClick={() => { setTab(k); if(k==='list') loadEntries() }}
            className={`px-5 py-2 rounded-lg text-sm font-medium transition-all ${tab===k?'bg-sapphire-500 text-white':'text-slate-400 hover:text-white'}`}>
            {l}
          </button>
        ))}
      </div>

      {/* Manuel form */}
      {tab === 'manual' && (
        <div className="bg-ink-900 border border-white/6 rounded-2xl p-6">
          <h3 className="font-display font-600 text-white text-base mb-5 flex items-center gap-2">
            <PlusCircle size={16} className="text-sapphire-400"/> Satış Kaydı Ekle
          </h3>

          {error && <div className="mb-4 flex items-center gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-sm"><AlertCircle size={14}/>{error}</div>}

          {lastRecord && (
            <div className="mb-5 p-4 rounded-xl bg-sapphire-500/10 border border-sapphire-500/20">
              <p className="text-sapphire-400 text-sm flex items-center gap-1.5 font-medium">
                <CheckCircle2 size={14}/> Kayıt şifrelendi ve veritabanına yazıldı
              </p>
              <p className="text-xs text-slate-500 mt-1">Bu işlemden sonra sayısal alanlar DB'de yalnızca ciphertext olarak tutulur.</p>
              <CipherText preview={lastRecord.ciphertext_preview} sizeBytes={lastRecord.ciphertext_size_bytes} />
            </div>
          )}

          <form onSubmit={submitManual} className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-slate-400 mb-1.5 uppercase tracking-wider">Ürün Adı</label>
                <input name="product_name" value={form.product_name} onChange={handle} required
                  placeholder="örn. Organik Süt 1L"
                  className="w-full px-4 py-3 bg-ink-800 border border-white/10 focus:border-sapphire-500/60 rounded-xl text-white text-sm outline-none transition-colors placeholder-slate-600"/>
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1.5 uppercase tracking-wider">Kategori</label>
                <select name="category" value={form.category} onChange={handle} required
                  className="w-full px-4 py-3 bg-ink-800 border border-white/10 focus:border-sapphire-500/60 rounded-xl text-sm text-white outline-none transition-colors">
                  <option value="">Seçin</option>
                  {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
            </div>

            <div className="grid md:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs text-slate-400 mb-1.5 uppercase tracking-wider">Satış Adedi</label>
                <input name="quantity_sold" type="number" min="1" value={form.quantity_sold} onChange={handle} required placeholder="100"
                  className="w-full px-4 py-3 bg-ink-800 border border-white/10 focus:border-sapphire-500/60 rounded-xl text-white text-sm outline-none transition-colors placeholder-slate-600"/>
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1.5 uppercase tracking-wider">Birim Fiyat (₺)</label>
                <input name="unit_price" type="number" min="0.01" step="0.01" value={form.unit_price} onChange={handle} required placeholder="49.90"
                  className="w-full px-4 py-3 bg-ink-800 border border-white/10 focus:border-sapphire-500/60 rounded-xl text-white text-sm outline-none transition-colors placeholder-slate-600"/>
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1.5 uppercase tracking-wider">Satış Tarihi</label>
                <input name="sale_date" type="date" value={form.sale_date} onChange={handle} required
                  className="w-full px-4 py-3 bg-ink-800 border border-white/10 focus:border-sapphire-500/60 rounded-xl text-white text-sm outline-none transition-colors"/>
              </div>
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1.5 uppercase tracking-wider">Bölge</label>
              <select name="region" value={form.region} onChange={handle}
                className="w-full px-4 py-3 bg-ink-800 border border-white/10 focus:border-sapphire-500/60 rounded-xl text-sm text-white outline-none transition-colors">
                {REGIONS.map(r => <option key={r} value={r}>{r}</option>)}
              </select>
            </div>

            {form.quantity_sold && form.unit_price && (
              <div className="p-3 rounded-xl bg-ink-800/50 border border-white/6 flex justify-between">
                <span className="text-xs text-slate-400">Toplam Tutar</span>
                <span className="font-mono text-sapphire-400 text-sm font-600">
                  {fmt(parseFloat(form.unit_price||0)*parseInt(form.quantity_sold||0))}
                </span>
              </div>
            )}

            <button type="submit" disabled={busy}
              className="w-full py-3 bg-sapphire-500 hover:bg-sapphire-400 disabled:opacity-50 text-white rounded-xl font-semibold text-sm transition-colors flex items-center justify-center gap-2">
              {busy
                ? <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"/>
                : <><Lock size={14}/> Şifrele & Kaydet</>}
            </button>
          </form>
        </div>
      )}

      {/* CSV */}
      {tab === 'csv' && (
        <div className="bg-ink-900 border border-white/6 rounded-2xl p-6">
          <h3 className="font-display font-600 text-white text-base mb-2 flex items-center gap-2">
            <Upload size={16} className="text-sapphire-400"/> CSV Dosyası Yükle
          </h3>
          <p className="text-xs text-slate-500 mb-5">Tüm satırlar otomatik CKKS ile şifrelenerek kaydedilir.</p>

          <div className="mb-5 p-4 rounded-xl bg-ink-800/50 border border-white/6">
            <p className="text-xs text-slate-400 font-medium mb-2">Gerekli CSV Formatı:</p>
            <code className="text-xs text-sapphire-300 font-mono block">product_name, category, quantity_sold, unit_price, sale_date, region</code>
            <code className="text-xs text-slate-500 font-mono block mt-1">Organik Süt 1L, Gıda & İçecek, 120, 32.90, 2025-06-15, Marmara</code>
          </div>

          {error && <div className="mb-4 flex items-center gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-sm"><AlertCircle size={14}/>{error}</div>}
          {csvResult && (
            <div className="mb-4 p-3 rounded-lg bg-sapphire-500/10 border border-sapphire-500/20 text-sm">
              <p className="text-sapphire-400 flex items-center gap-1"><CheckCircle2 size={14}/>{csvResult.message}</p>
              {csvResult.errors?.length > 0 && <p className="text-xs text-red-400 mt-1">{csvResult.errors.join(' | ')}</p>}
            </div>
          )}

          <div className="border-2 border-dashed border-white/10 hover:border-sapphire-500/40 rounded-xl p-10 text-center cursor-pointer transition-colors"
            onClick={() => fileRef.current?.click()}
            onDragOver={e => e.preventDefault()}
            onDrop={e => { e.preventDefault(); const f=e.dataTransfer.files[0]; if(f?.name.endsWith('.csv')) setCsvFile(f) }}>
            <Upload size={28} className="text-slate-600 mx-auto mb-3"/>
            <p className="text-slate-400 text-sm mb-1">CSV dosyasını sürükleyin veya tıklayın</p>
            {csvFile && <p className="mt-3 text-sapphire-400 text-sm font-medium">📄 {csvFile.name}</p>}
            <input ref={fileRef} type="file" accept=".csv" className="hidden" onChange={e => setCsvFile(e.target.files[0])}/>
          </div>

          {csvFile && (
            <div className="mt-4 flex gap-3">
              <button onClick={submitCSV} disabled={busy}
                className="flex-1 py-3 bg-sapphire-500 hover:bg-sapphire-400 disabled:opacity-50 text-white rounded-xl font-semibold text-sm transition-colors flex items-center justify-center gap-2">
                {busy ? <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"/> : <><Lock size={14}/> Şifrele & Yükle</>}
              </button>
              <button onClick={() => { setCsvFile(null); if(fileRef.current) fileRef.current.value='' }}
                className="px-4 py-3 border border-white/10 hover:border-red-500/40 text-slate-400 hover:text-red-400 rounded-xl text-sm transition-colors">
                <Trash2 size={14}/>
              </button>
            </div>
          )}
        </div>
      )}

      {/* Kayıt listesi */}
      {tab === 'list' && (
        <div className="bg-ink-900 border border-white/6 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-5">
            <h3 className="font-display font-600 text-white text-base">Son Kayıtlar</h3>
            <button onClick={loadEntries} className="text-slate-400 hover:text-white transition-colors">
              <RefreshCw size={14} className={entriesLoading ? 'animate-spin' : ''}/>
            </button>
          </div>

          {entries.length === 0 ? (
            <p className="text-slate-500 text-sm text-center py-8">Henüz kayıt yok</p>
          ) : (
            <div className="space-y-2">
              {entries.map(e => (
                <div key={e.id} className="flex items-center gap-4 p-3 rounded-xl bg-ink-800/50 border border-white/6">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-white text-sm font-medium truncate">{e.product_name}</span>
                      <span className="text-xs px-1.5 py-0.5 rounded bg-ink-700 text-slate-400">{e.category}</span>
                      {e.is_shared
                        ? <span className="text-xs px-1.5 py-0.5 rounded bg-sapphire-500/20 text-sapphire-400 flex items-center gap-1"><Share2 size={9}/> Paylaşıldı</span>
                        : <span className="text-xs px-1.5 py-0.5 rounded bg-ink-700 text-slate-500 flex items-center gap-1"><Lock size={9}/> Özel</span>
                      }
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">{e.sale_date} · {e.region}</p>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p className="font-mono text-sapphire-400 text-sm">{fmt(e.total_revenue)}</p>
                    <p className="text-xs text-slate-500">{e.quantity_sold} adet</p>
                  </div>
                  <button onClick={() => toggleShare(e.id)}
                    className={`flex-shrink-0 px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors border ${
                      e.is_shared
                        ? 'border-red-500/20 text-red-400 hover:bg-red-500/10'
                        : 'border-sapphire-500/20 text-sapphire-400 hover:bg-sapphire-500/10'
                    }`}>
                    {e.is_shared ? 'Geri Al' : 'Paylaş'}
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
