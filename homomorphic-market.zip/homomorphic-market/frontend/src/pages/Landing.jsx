import { Link } from 'react-router-dom'
import { Shield, BarChart3, Lock, Zap, ChevronRight, TrendingUp, Database, Globe, ArrowRight } from 'lucide-react'

const FEATURES = [
  { icon: Shield,    title: 'Homomorfik Şifreleme',   desc: 'Backend, satış sayılarını veritabanına yazmadan önce CKKS ile şifreler. İstek sırasında sayılar uygulama sunucusuna açık olarak ulaşır.' },
  { icon: BarChart3, title: 'Kurumsal Pazar Analizi',  desc: 'Toplam satış, kategori performansı, mevsimsel talep ve sektör karşılaştırması.' },
  { icon: Lock,      title: 'Kurum Bazlı Anahtarlar', desc: 'Her kurumun CKKS anahtar çifti sunucuda oluşturulur; secret context uygulama anahtarıyla korunarak sunucuda saklanır.' },
  { icon: Zap,       title: 'Sahip Yetkili Analiz',  desc: 'Sahip analizlerinde bazı toplamlar ciphertext üzerinde hesaplanır; backend sonucu kendi sakladığı secret key ile çözer.' },
  { icon: Globe,     title: 'Sektör Karşılaştırması', desc: 'Paylaşılan kayıtlar üzerinden merkezi sunucunun çözdüğü bir demo sıralama sunulur. Bu işlem gizli HE sıralaması değildir.' },
  { icon: TrendingUp,'title': 'Trend & Analiz',        desc: 'Ürün ve dönem kırılımları, backend tarafından çözülen değerlerle hesaplanır.' },
]

const STATS = [
  { value: 'CKKS', label: 'Şifreleme Şeması' },
  { value: '8192', label: 'Polinom Derecesi' },
  { value: '2⁴⁰',  label: 'Global Scale' },
  { value: 'DB', label: 'Sayılar ciphertext' },
]

export default function Landing() {
  return (
    <div className="min-h-screen bg-ink-950 font-body overflow-x-hidden text-slate-300">

      {/* Nav */}
      <nav className="fixed top-0 left-0 right-0 z-50 border-b border-white/5 bg-ink-950/90 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-6 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-sapphire-600 flex items-center justify-center">
              <Database size={13} className="text-white" />
            </div>
            <span className="font-semibold text-white text-sm tracking-tight">CipherMarket</span>
          </div>
          <div className="flex items-center gap-2">
            <Link to="/login" className="px-4 py-1.5 text-sm text-slate-400 hover:text-white transition-colors">
              Giriş Yap
            </Link>
            <Link to="/register" className="btn-primary px-4 py-1.5 text-sm">
              Başlayın
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative pt-36 pb-28 px-6 overflow-hidden">
        <div className="absolute inset-0 bg-grid-fine bg-grid-fine opacity-100 pointer-events-none" />
        <div className="absolute inset-0 bg-hero-glow pointer-events-none" />

        <div className="relative max-w-5xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-sapphire-600/30 bg-sapphire-600/10 text-sapphire-300 text-xs font-medium mb-10">
            <span className="w-1.5 h-1.5 rounded-full bg-sapphire-400 pulse-dot" />
            TenSEAL CKKS · Kurum Bazlı Anahtar Yönetimi
          </div>

          <h1 className="text-5xl md:text-[64px] font-bold text-white leading-[1.06] mb-6 tracking-tight">
            Şifreli Veri Üzerinde<br />
            <span className="text-sapphire-400">Pazar Analizi</span>
          </h1>

          <p className="text-slate-400 text-lg max-w-2xl mx-auto mb-10 leading-relaxed font-light">
            Ham satış verilerinizi açığa çıkarmadan sektör analizi yapın.
            Rakipler yalnızca şifreli veriyi görür — hesaplamalar doğrudan ciphertext üzerinde.
          </p>

          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link to="/register"
              className="btn-primary inline-flex items-center gap-2 px-6 py-3 text-sm glow-blue">
              Kurumunuzu Kaydedin <ArrowRight size={15} />
            </Link>
            <Link to="/login"
              className="btn-ghost inline-flex items-center gap-2 px-6 py-3 text-sm">
              Giriş Yap
            </Link>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="border-y border-white/5 bg-ink-900/50">
        <div className="max-w-5xl mx-auto px-6 py-10 grid grid-cols-2 md:grid-cols-4 gap-8">
          {STATS.map(s => (
            <div key={s.label} className="text-center">
              <div className="font-mono text-2xl font-semibold text-white mb-1">{s.value}</div>
              <div className="text-xs text-slate-600 uppercase tracking-widest">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="py-24 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-14">
            <h2 className="text-3xl font-bold text-white mb-3 tracking-tight">Platform Özellikleri</h2>
            <p className="text-slate-500 max-w-md mx-auto text-sm">Kurumsal veri güvenliği ile analitik gücü aynı platformda.</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {FEATURES.map(f => (
              <div key={f.title} className="card card-hover p-5 rounded-xl">
                <div className="w-8 h-8 rounded-lg bg-sapphire-600/15 border border-sapphire-600/20 flex items-center justify-center mb-3">
                  <f.icon size={15} className="text-sapphire-400" />
                </div>
                <h3 className="font-semibold text-white text-sm mb-1.5">{f.title}</h3>
                <p className="text-slate-500 text-xs leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="py-20 px-6 bg-ink-900/30 border-y border-white/5">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-2xl font-bold text-white mb-2 tracking-tight">Nasıl Çalışır?</h2>
          <p className="text-slate-500 text-sm mb-14">Üç adımda CKKS ile şifreli sayısal analiz</p>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { step:'01', title:'Kayıt & Anahtar Üretimi', desc:'Backend kayıt sırasında kuruma özel CKKS anahtar çifti üretir ve secret context’i kendi yapılandırma anahtarıyla koruyup saklar.' },
              { step:'02', title:'Veri Şifreleme',          desc:'Girdiğiniz satış verileri public key ile şifrelenir. DB\'de yalnızca şifreli veri saklanır.' },
              { step:'03', title:'Şifreli Analiz',          desc:'Dashboard ve rakip karşılaştırmaları doğrudan ciphertext üzerinde hesaplanır.' },
            ].map(item => (
              <div key={item.step}>
                <div className="font-mono text-5xl font-bold text-sapphire-600/20 mb-3">{item.step}</div>
                <h3 className="font-semibold text-white text-sm mb-2">{item.title}</h3>
                <p className="text-slate-500 text-xs leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-6">
        <div className="max-w-xl mx-auto text-center">
          <h2 className="text-2xl font-bold text-white mb-3 tracking-tight">Hemen Başlayın</h2>
          <p className="text-slate-500 text-sm mb-7">Kurumunuzu kaydedin, verilerinizi girin ve analizi başlatın.</p>
          <Link to="/register"
            className="btn-primary inline-flex items-center gap-2 px-7 py-3 text-sm">
            Ücretsiz Kayıt <ChevronRight size={15} />
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-white/5 py-6 px-6 text-center text-slate-700 text-xs">
        © 2025 CipherMarket · Homomorfik Şifreleme ile Kurumsal Veri Analitiği
      </footer>
    </div>
  )
}
