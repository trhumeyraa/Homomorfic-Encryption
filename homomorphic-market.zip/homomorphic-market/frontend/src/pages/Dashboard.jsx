import { useState, useEffect, useCallback } from 'react'
import { useAuth } from '../hooks/useAuth.jsx'
import api from '../utils/api.js'
import {
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from 'recharts'
import {
  LayoutDashboard, TrendingUp, ShoppingBag, GitCompare,
  Cpu, LogOut, Menu, Sun, Map, Layers,
  ArrowUpRight, ArrowDownRight, Database, PlusCircle, Swords, UserCircle
} from 'lucide-react'
import DataEntry   from './DataEntry.jsx'
import Competitive from './Competitive.jsx'
import Profile     from './Profile.jsx'

const COLORS = ['#3b82f6','#60a5fa','#93c5fd','#1d4ed8','#2563eb','#1e40af','#dbeafe','#bfdbfe']
const MONTH_NAMES = ['','Oca','Şub','Mar','Nis','May','Haz','Tem','Ağu','Eyl','Eki','Kas','Ara']
const fmt  = n => n == null ? 'Şifreli' : new Intl.NumberFormat('tr-TR',{style:'currency',currency:'TRY',maximumFractionDigits:0}).format(n)
const fmtN = n => n == null ? 'Şifreli' : new Intl.NumberFormat('tr-TR').format(n)

const NAV = [
  { id:'overview',    label:'Genel Bakış',          icon:LayoutDashboard },
  { id:'monthly',     label:'Aylık Trend',           icon:TrendingUp      },
  { id:'categories',  label:'Kategoriler',           icon:Layers          },
  { id:'products',    label:'Ürünler',               icon:ShoppingBag     },
  { id:'regional',    label:'Bölgesel',              icon:Map             },
  { id:'seasonal',    label:'Mevsimsel',             icon:Sun             },
  { id:'comparison',  label:'Pazar Karşılaştırması', icon:GitCompare      },
  { id:'homomorphic', label:'HE Demo',               icon:Cpu             },
  { id:'dataentry',   label:'Veri Girişi',           icon:PlusCircle      },
  { id:'competitive', label:'Rakip Analizi',         icon:Swords          },
  { id:'profile',     label:'Profil',                icon:UserCircle      },
]

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-ink-800 border border-white/10 rounded-xl p-3 text-xs shadow-2xl">
      <p className="text-slate-400 mb-1.5 font-medium">{label}</p>
      {payload.map((p,i) => (
        <p key={i} style={{color:p.color||p.fill}} className="font-mono">
          {p.name}: {typeof p.value==='number' && p.value>999 ? fmt(p.value) : fmtN(p.value)}
        </p>
      ))}
    </div>
  )
}

function Spinner() {
  return (
    <div className="flex items-center justify-center h-48">
      <div className="w-6 h-6 border-2 border-sapphire-500 border-t-transparent rounded-full animate-spin" />
    </div>
  )
}

function EmptyState({ onGo }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center fade-in">
      <div className="w-10 h-10 rounded-xl bg-ink-700 border border-white/8 flex items-center justify-center mb-3">
        <PlusCircle size={18} className="text-slate-500" />
      </div>
      <p className="text-slate-500 text-sm mb-4">Henüz veri yok</p>
      <button onClick={onGo}
        className="flex items-center gap-2 px-4 py-2 text-xs text-sapphire-400 border border-sapphire-600/25 hover:bg-sapphire-600/10 rounded-lg transition-colors">
        <PlusCircle size={12} /> Veri Girişine Git
      </button>
    </div>
  )
}

function StatCard({ title, value, icon:Icon, trend }) {
  const up = trend >= 0
  return (
    <div className="card card-hover rounded-xl p-5">
      <div className="flex items-start justify-between mb-4">
        <div className="w-8 h-8 rounded-lg bg-sapphire-600/12 border border-sapphire-600/18 flex items-center justify-center">
          <Icon size={14} className="text-sapphire-400" />
        </div>
        {trend !== undefined && (
          <span className={`flex items-center gap-0.5 text-xs font-mono font-medium ${up?'text-green-400':'text-red-400'}`}>
            {up ? <ArrowUpRight size={12}/> : <ArrowDownRight size={12}/>}
            {Math.abs(trend).toFixed(1)}%
          </span>
        )}
      </div>
      <div className="stat-number mb-0.5">{value}</div>
      <div className="text-xs text-slate-600 font-medium uppercase tracking-wider">{title}</div>
    </div>
  )
}

function Section({ title, children }) {
  return (
    <div className="card rounded-xl p-6">
      <h3 className="text-sm font-semibold text-white mb-5 tracking-tight">{title}</h3>
      {children}
    </div>
  )
}

export default function Dashboard() {
  const { user, logout } = useAuth()
  const [active, setActive]   = useState('overview')
  const [sideOpen, setSide]   = useState(false)
  const [data, setData]       = useState({})
  const [loading, setLoading] = useState({})

  const load = useCallback(async (key, endpoint) => {
    if (data[key]) return
    setLoading(l => ({ ...l, [key]:true }))
    try {
      const { data:d } = await api.get(endpoint)
      setData(prev => ({ ...prev, [key]:d }))
    } catch {}
    finally { setLoading(l => ({ ...l, [key]:false })) }
  }, [data])

  useEffect(() => {
    load('overview',   '/analytics/dashboard')
    load('monthly',    '/analytics/monthly')
    load('categories', '/analytics/categories')
    load('products',   '/analytics/products/top?limit=10')
    load('regional',   '/analytics/regional')
    load('seasonal',   '/analytics/seasonal')
    load('comparison', '/analytics/market-comparison')
    load('homomorphic','/analytics/homomorphic/demo')
  }, []) // eslint-disable-line

  const isLoading = key => loading[key]

  // ── Panels ──────────────────────────────────────────────────────────────────
  const Overview = () => {
    const d = data.overview
    if (isLoading('overview')) return <Spinner />
    if (!d) return null
    if (d.total_revenue === 0 && d.active_products === 0) return (
      <div className="flex flex-col items-center justify-center py-20 text-center fade-in">
        <div className="w-14 h-14 rounded-2xl bg-sapphire-600/12 border border-sapphire-600/20 flex items-center justify-center mb-5">
          <PlusCircle size={24} className="text-sapphire-400" />
        </div>
        <h2 className="font-bold text-xl text-white mb-2 tracking-tight">Henüz veri yok</h2>
        <p className="text-slate-500 text-sm mb-6 max-w-sm">Analizi görmek için satış verisi ekleyin. Tüm veriler CKKS şemasıyla şifrelenir.</p>
        <button onClick={() => setActive('dataentry')}
          className="btn-primary flex items-center gap-2 px-5 py-2.5 text-sm">
          <PlusCircle size={14} /> Veri Girişine Git
        </button>
      </div>
    )
    return (
      <div className="space-y-5 fade-in">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard title="Toplam Gelir"       value={fmt(d.total_revenue)}   icon={TrendingUp} trend={d.revenue_change_percent} />
          <StatCard title="Toplam Satış Adedi" value={fmtN(d.total_quantity)} icon={ShoppingBag} />
          <StatCard title="Ort. Birim Fiyat"   value={fmt(d.avg_unit_price)}  icon={Layers} />
          <StatCard title="Aktif Ürün"         value={d.active_products}       icon={Database} />
        </div>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="card rounded-xl p-4">
            <p className="text-xs text-slate-600 mb-1 uppercase tracking-wider">En Yüksek Kategori</p>
            <p className="font-semibold text-white">{d.top_category}</p>
          </div>
          <div className="card rounded-xl p-4">
            <p className="text-xs text-slate-600 mb-1 uppercase tracking-wider">En Çok Satan Ürün</p>
            <p className="font-semibold text-white truncate">{d.top_product}</p>
          </div>
        </div>
        {data.monthly && data.monthly.length > 0 && (
          <Section title="Son 12 Ay Gelir Trendi">
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={data.monthly.map(m => ({ ...m, name:`${MONTH_NAMES[m.month]} ${m.year}` }))}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                <XAxis dataKey="name" tick={{ fill:'#475569', fontSize:10 }} />
                <YAxis tickFormatter={v => `${(v/1000).toFixed(0)}K`} tick={{ fill:'#475569', fontSize:10 }} />
                <Tooltip content={<CustomTooltip />} />
                <Line type="monotone" dataKey="total_revenue" stroke="#3b82f6" strokeWidth={2} dot={false} name="Gelir" />
              </LineChart>
            </ResponsiveContainer>
          </Section>
        )}
      </div>
    )
  }

  const Monthly = () => {
    const d = data.monthly
    if (isLoading('monthly')) return <Spinner />
    if (!d || d.length === 0) return <EmptyState onGo={() => setActive('dataentry')} />
    const chart = d.map(m => ({ ...m, name:`${MONTH_NAMES[m.month]}/${String(m.year).slice(2)}` }))
    return (
      <div className="space-y-5 fade-in">
        <Section title="Aylık Gelir">
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={chart}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
              <XAxis dataKey="name" tick={{ fill:'#475569', fontSize:10 }} />
              <YAxis tickFormatter={v => `${(v/1000).toFixed(0)}K`} tick={{ fill:'#475569', fontSize:10 }} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="total_revenue" fill="#2563eb" radius={[3,3,0,0]} name="Gelir" />
            </BarChart>
          </ResponsiveContainer>
        </Section>
        <Section title="Aylık Satış & Ortalama Fiyat">
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={chart}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
              <XAxis dataKey="name" tick={{ fill:'#475569', fontSize:10 }} />
              <YAxis tick={{ fill:'#475569', fontSize:10 }} />
              <Tooltip content={<CustomTooltip />} />
              <Line type="monotone" dataKey="total_quantity" stroke="#60a5fa" strokeWidth={2} dot={false} name="Adet" />
              <Line type="monotone" dataKey="avg_price" stroke="#f59e0b" strokeWidth={1.5} dot={false} name="Ort. Fiyat" strokeDasharray="4 2" />
            </LineChart>
          </ResponsiveContainer>
        </Section>
      </div>
    )
  }

  const Categories = () => {
    const d = data.categories
    if (isLoading('categories')) return <Spinner />
    if (!d || d.length === 0) return <EmptyState onGo={() => setActive('dataentry')} />
    return (
      <div className="space-y-5 fade-in">
        <Section title="Kategori Gelir Dağılımı">
          <ResponsiveContainer width="100%" height={240}>
            <PieChart>
              <Pie data={d} dataKey="total_revenue" nameKey="category" cx="50%" cy="50%" outerRadius={95}
                label={({ category, percent }) => `${category} ${(percent*100).toFixed(0)}%`} labelLine={false}>
                {d.map((_,i) => <Cell key={i} fill={COLORS[i%COLORS.length]} />)}
              </Pie>
              <Tooltip formatter={v => fmt(v)} />
            </PieChart>
          </ResponsiveContainer>
        </Section>
        <Section title="Kategori Detayları">
          <div className="space-y-2">
            {d.map((cat,i) => (
              <div key={cat.category} className="flex items-center gap-3 p-3 rounded-lg bg-ink-700/40 border border-white/4">
                <div className="w-2.5 h-2.5 rounded-sm flex-shrink-0" style={{background:COLORS[i%COLORS.length]}} />
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-200 font-medium">{cat.category}</span>
                    <span className="font-mono text-sm text-sapphire-400">{fmt(cat.total_revenue)}</span>
                  </div>
                  <div className="flex gap-4 mt-0.5">
                    <span className="text-xs text-slate-600">{fmtN(cat.total_quantity)} adet</span>
                    <span className="text-xs text-slate-600">{cat.product_count} ürün</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Section>
      </div>
    )
  }

  const Products = () => {
    const d = data.products
    if (isLoading('products')) return <Spinner />
    if (!d || d.length === 0) return <EmptyState onGo={() => setActive('dataentry')} />
    return (
      <div className="fade-in">
        <Section title="En Çok Satan 10 Ürün">
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={d} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" horizontal={false} />
              <XAxis type="number" tickFormatter={v => `${(v/1000).toFixed(0)}K`} tick={{ fill:'#475569', fontSize:10 }} />
              <YAxis type="category" dataKey="product_name" width={140} tick={{ fill:'#94a3b8', fontSize:10 }} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="total_revenue" fill="#2563eb" radius={[0,3,3,0]} name="Gelir" />
            </BarChart>
          </ResponsiveContainer>
        </Section>
      </div>
    )
  }

  const Regional = () => {
    const d = data.regional
    if (isLoading('regional')) return <Spinner />
    if (!d || d.length === 0) return <EmptyState onGo={() => setActive('dataentry')} />
    const max = Math.max(...d.map(r => r.total_revenue))
    return (
      <div className="fade-in space-y-5">
        <Section title="Bölgesel Satış Dağılımı">
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={d}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
              <XAxis dataKey="region" tick={{ fill:'#475569', fontSize:10 }} />
              <YAxis tickFormatter={v => `${(v/1000).toFixed(0)}K`} tick={{ fill:'#475569', fontSize:10 }} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="total_revenue" fill="#2563eb" radius={[3,3,0,0]} name="Gelir" />
            </BarChart>
          </ResponsiveContainer>
          <div className="mt-4 space-y-2.5">
            {d.map(r => (
              <div key={r.region} className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">{r.region}</span>
                  <span className="font-mono text-sapphire-400">{fmt(r.total_revenue)}</span>
                </div>
                <div className="h-1 bg-ink-700 rounded-full overflow-hidden">
                  <div className="h-full bg-sapphire-600 rounded-full" style={{width:`${(r.total_revenue/max)*100}%`}} />
                </div>
              </div>
            ))}
          </div>
        </Section>
      </div>
    )
  }

  const Seasonal = () => {
    const d = data.seasonal
    if (isLoading('seasonal')) return <Spinner />
    if (!d || d.length === 0) return <EmptyState onGo={() => setActive('dataentry')} />
    const ORDER = ['İlkbahar','Yaz','Sonbahar','Kış']
    const sorted = [...d].sort((a,b) => ORDER.indexOf(a.season)-ORDER.indexOf(b.season))
    const SC = { İlkbahar:'#34d399', Yaz:'#f59e0b', Sonbahar:'#f97316', Kış:'#60a5fa' }
    return (
      <div className="fade-in space-y-5">
        <Section title="Mevsimsel Talep Analizi">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
            {sorted.map(s => (
              <div key={s.season} className="p-4 rounded-xl bg-ink-700/40 border border-white/4 text-center">
                <div className="text-2xl mb-1">{{ İlkbahar:'🌸', Yaz:'☀️', Sonbahar:'🍂', Kış:'❄️' }[s.season]}</div>
                <div className="font-semibold text-white text-sm mb-0.5">{s.season}</div>
                <div className="font-mono text-xs" style={{color:SC[s.season]}}>{fmt(s.total_revenue)}</div>
              </div>
            ))}
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={sorted}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
              <XAxis dataKey="season" tick={{ fill:'#475569', fontSize:11 }} />
              <YAxis tickFormatter={v => `${(v/1000).toFixed(0)}K`} tick={{ fill:'#475569', fontSize:10 }} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="total_revenue" radius={[3,3,0,0]} name="Gelir">
                {sorted.map((s,i) => <Cell key={i} fill={SC[s.season]||'#3b82f6'} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </Section>
      </div>
    )
  }

  const Comparison = () => {
    const d = data.comparison
    if (isLoading('comparison')) return <Spinner />
    if (!d || d.length === 0) return <EmptyState onGo={() => setActive('dataentry')} />
    return (
      <div className="fade-in space-y-4">
        <div className="p-3 rounded-xl bg-sapphire-600/8 border border-sapphire-600/18 text-xs text-sapphire-300 flex items-center gap-2">
          <Cpu size={12}/> Diğer kurumların adları gösterilmez; sabit kurum numarası ile sektör, şehir ve seçili metadata alanları görünür.
        </div>
        <Section title="Pazar Karşılaştırması">
          <div className="space-y-2">
            {d.map((item,i) => (
              <div key={i} className={`flex items-center gap-4 p-4 rounded-xl border transition-colors ${
                item.institution_name === user?.name
                  ? 'bg-sapphire-600/8 border-sapphire-600/25'
                  : 'bg-ink-700/30 border-white/4'
              }`}>
                <div className={`w-7 h-7 rounded-lg flex items-center justify-center font-semibold text-xs flex-shrink-0 ${
                  item.institution_name === user?.name ? 'bg-sapphire-600 text-white' : 'bg-ink-600 text-slate-500'
                }`}>{i+1}</div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-white font-medium">{item.institution_name}</span>
                    {item.institution_name === user?.name && <span className="badge-blue">Siz</span>}
                  </div>
                  <div className="text-xs text-slate-600 mt-0.5">{item.sector} · {item.city}</div>
                </div>
                <div className="text-right flex-shrink-0">
                  <div className={`font-mono text-sm ${item.encrypted_only ? 'text-slate-500 tracking-widest' : 'text-sapphire-400'}`}>
                    {item.encrypted_only ? '••••••' : fmt(item.total_revenue)}
                  </div>
                  <div className="text-xs text-slate-600">
                    {item.encrypted_only ? `${item.shared_record_count || 0} şifreli kayıt` : `${fmtN(item.total_quantity)} adet`}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Section>
      </div>
    )
  }

  const HomomorphicDemo = () => {
    const d = data.homomorphic
    if (isLoading('homomorphic')) return <Spinner />
    if (!d || d.error) return (
      <div className="text-center py-16 fade-in">
        <Cpu size={28} className="text-slate-600 mx-auto mb-3" />
        <p className="text-slate-500 text-sm mb-1">{d?.error || 'Veri yüklenemedi'}</p>
        {d?.hint && <p className="text-xs text-slate-600">{d.hint}</p>}
      </div>
    )
    const ops = d.operations || {}
    return (
      <div className="fade-in space-y-5">
        <div className="p-4 rounded-xl bg-sapphire-600/10 border border-sapphire-600/25">
          <div className="flex items-center gap-2 text-sapphire-300 font-medium text-sm mb-1"><Cpu size={14}/> Homomorfik Şifreleme Performans Analizi</div>
          <p className="text-xs text-slate-500">{d.explanation?.tr}</p>
          <p className="text-xs text-slate-400 mt-0.5 font-mono">{d.data_points} veri noktası · tek çalıştırma örneği · sonuç backend tarafından secret context ile çözülür</p>
        </div>
        {Object.entries(ops).map(([opName, op]) => (
          <Section key={opName} title={opName==='sum'?'Şifreli Toplama (Sum)':'Şifreli Ortalama (Mean)'}>
            <div className="grid md:grid-cols-2 gap-4 mb-4">
              <div className="p-4 rounded-xl bg-ink-700/55 border border-white/8">
                <div className="text-xs text-slate-400 mb-1 uppercase tracking-wider">Düz Metin Hesaplama</div>
                <div className="font-mono text-lg text-slate-200 font-semibold">{fmt(op.plain_result)}</div>
                <div className="text-xs text-slate-400 mt-1">{op.plain_time_ms} ms · referans sonuç</div>
              </div>
              <div className="p-4 rounded-xl bg-sapphire-600/12 border border-sapphire-600/25">
                <div className="text-xs text-sapphire-300 mb-1 uppercase tracking-wider">CKKS İşlem Sonucu, Çözülmüş</div>
                <div className="font-mono text-lg text-sapphire-300 font-semibold">{fmt(op.encrypted_result)}</div>
                <div className="text-xs text-sapphire-200/80 mt-1">{op.encrypted_time_ms} ms · şifrele + HE işlemi + çözme</div>
              </div>
            </div>
            <div className="mb-3 p-3 rounded-lg bg-ink-700/45 border border-white/8 text-xs">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-slate-300 font-medium">Ciphertext önizlemesi:</span>
                <span className="font-mono text-slate-400 break-all">{op.ciphertext_preview || '••••••••••••••••'}</span>
                {op.ciphertext_bytes && <span className="text-slate-500">({op.ciphertext_bytes} byte)</span>}
              </div>
              <p className="text-slate-500 mt-1">Bu değer okunabilir sonuç değil; veritabanında saklanan şifreli payload'ın kısa temsilidir.</p>
            </div>
            <div className="flex items-center gap-3 p-3 rounded-lg bg-ink-700/45 border border-white/8 text-xs">
              <span className="text-slate-400">Hesaplama Yükü:</span>
              <span className="font-mono text-white font-semibold">{op.overhead_factor}×</span>
              <span className="text-slate-400">oranı · tek çalıştırma, benchmark değildir</span>
            </div>
            <div className="mt-3">
              <div className="flex justify-between text-xs text-slate-400 mb-1">
                <span>Düz ({op.plain_time_ms}ms)</span>
                <span>CKKS ({op.encrypted_time_ms}ms)</span>
              </div>
              <div className="h-1.5 bg-ink-700 rounded-full overflow-hidden">
                <div className="h-full rounded-full bg-sapphire-600" style={{width:`${Math.min((1/op.overhead_factor)*100,100)}%`}} />
              </div>
            </div>
          </Section>
        ))}
      </div>
    )
  }

  const PANELS = {
    overview: Overview, monthly: Monthly, categories: Categories, products: Products,
    regional: Regional, seasonal: Seasonal, comparison: Comparison, homomorphic: HomomorphicDemo,
    dataentry: DataEntry, competitive: Competitive, profile: Profile
  }
  const ActivePanel = PANELS[active] || Overview

  return (
    <div className="min-h-screen bg-ink-950 flex font-body">

      {/* Sidebar */}
      <aside className={`fixed lg:sticky top-0 left-0 h-screen w-60 bg-ink-900 border-r border-white/5 flex flex-col z-40 transition-transform duration-300 ${sideOpen?'translate-x-0':'-translate-x-full lg:translate-x-0'}`}>
        <div className="p-4 border-b border-white/5">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-sapphire-600 flex items-center justify-center flex-shrink-0">
              <Database size={13} className="text-white" />
            </div>
            <span className="font-semibold text-white text-sm tracking-tight">CipherMarket</span>
          </div>
          <div className="mt-3 px-2 py-2 rounded-lg bg-ink-800 border border-white/5">
            <div className="text-xs text-slate-600 mb-0.5">Kurum</div>
            <div className="text-sm text-slate-200 font-medium truncate">{user?.name}</div>
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto py-2">
          {/* Grup: Analiz */}
          <div className="px-3 pt-2 pb-1">
            <p className="text-xs text-slate-700 uppercase tracking-widest font-medium mb-1">Analiz</p>
            {NAV.slice(0,8).map(n => (
              <button key={n.id} onClick={() => { setActive(n.id); setSide(false) }}
                className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm transition-all mb-0.5 ${
                  active===n.id ? 'nav-active' : 'nav-item'
                }`}>
                <n.icon size={14} />
                {n.label}
              </button>
            ))}
          </div>
          <div className="border-t border-white/5 mx-3 my-1" />
          {/* Grup: Veri & Rakip */}
          <div className="px-3 py-1">
            <p className="text-xs text-slate-700 uppercase tracking-widest font-medium mb-1">Veri & Rekabet</p>
            {NAV.slice(8,10).map(n => (
              <button key={n.id} onClick={() => { setActive(n.id); setSide(false) }}
                className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm transition-all mb-0.5 ${
                  active===n.id ? 'nav-active' : 'nav-item'
                }`}>
                <n.icon size={14} />
                {n.label}
              </button>
            ))}
          </div>
        </nav>

        <div className="p-3 border-t border-white/5">
          <button onClick={() => { setActive('profile'); setSide(false) }}
            className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm mb-0.5 transition-all ${
              active==='profile' ? 'nav-active' : 'nav-item'
            }`}>
            <UserCircle size={14} /> Profil
          </button>
          <button onClick={logout}
            className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm nav-item text-red-500 hover:bg-red-500/8 hover:text-red-400 transition-all">
            <LogOut size={14} /> Çıkış Yap
          </button>
        </div>
      </aside>

      {sideOpen && <div className="fixed inset-0 bg-black/50 z-30 lg:hidden" onClick={() => setSide(false)} />}

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="sticky top-0 z-20 bg-ink-950/95 backdrop-blur border-b border-white/5 px-6 h-13 flex items-center justify-between" style={{height:'52px'}}>
          <div className="flex items-center gap-3">
            <button className="lg:hidden text-slate-500 hover:text-white transition-colors" onClick={() => setSide(true)}>
              <Menu size={18} />
            </button>
            <h1 className="text-sm font-semibold text-slate-300">
              {NAV.find(n => n.id===active)?.label || 'Dashboard'}
            </h1>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-green-400 pulse-dot" />
            <span className="text-xs text-slate-600 hidden sm:block">Canlı</span>
          </div>
        </header>
        <main className="flex-1 p-6 overflow-auto">
          <ActivePanel />
        </main>
      </div>
    </div>
  )
}
