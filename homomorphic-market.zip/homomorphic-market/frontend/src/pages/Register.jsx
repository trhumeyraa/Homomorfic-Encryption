import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Database, Eye, EyeOff, AlertCircle, CheckCircle2 } from 'lucide-react'
import api from '../utils/api.js'

const SECTORS = ['Gıda Perakende','Süpermarket Zinciri','Market & Bakkal','Elektronik & Teknoloji','Bilgisayar & Yazılım','Telefon & Aksesuar','Tekstil & Giyim','Ayakkabı & Çanta','Spor Giyim','Ev & Yaşam','Mobilya & Dekorasyon','Yapı Market & Hırdavat','Kozmetik & Kişisel Bakım','Eczane & Sağlık','Spor & Outdoor','Oyuncak & Hobi','Otomotiv Yan Sanayi','Yedek Parça','Kitap & Kırtasiye','Ofis Malzemeleri','Restoran & Kafe','Pastane & Fırın','İnşaat & Taahhüt','Tarım & Hayvancılık','Lojistik & Nakliye','Turizm & Otelcilik','Eğitim & Özel Kurs','Finans & Sigorta','Medya & Reklam','Diğer']
const CITIES  = ['Adana','Adıyaman','Afyonkarahisar','Ağrı','Amasya','Ankara','Antalya','Artvin','Aydın','Balıkesir','Bilecik','Bingöl','Bitlis','Bolu','Burdur','Bursa','Çanakkale','Çankırı','Çorum','Denizli','Diyarbakır','Edirne','Elazığ','Erzincan','Erzurum','Eskişehir','Gaziantep','Giresun','Gümüşhane','Hakkari','Hatay','Isparta','Mersin','İstanbul','İzmir','Kars','Kastamonu','Kayseri','Kırklareli','Kırşehir','Kocaeli','Konya','Kütahya','Malatya','Manisa','Kahramanmaraş','Mardin','Muğla','Muş','Nevşehir','Niğde','Ordu','Rize','Sakarya','Samsun','Siirt','Sinop','Sivas','Tekirdağ','Tokat','Trabzon','Tunceli','Şanlıurfa','Uşak','Van','Yozgat','Zonguldak','Aksaray','Bayburt','Karaman','Kırıkkale','Batman','Şırnak','Bartın','Ardahan','Iğdır','Yalova','Karabük','Kilis','Osmaniye','Düzce']

const errorText = detail => {
  if (!detail) return 'Kayıt başarısız'
  if (typeof detail === 'string') return detail
  if (Array.isArray(detail)) return detail.map(d => d.msg || JSON.stringify(d)).join(' | ')
  return JSON.stringify(detail)
}

export default function Register() {
  const navigate = useNavigate()
  const [form, setForm]     = useState({ name:'', email:'', password:'', tax_number:'', sector:'', city:'' })
  const [show, setShow]     = useState(false)
  const [error, setError]   = useState('')
  const [success, setSuccess] = useState(false)
  const [busy, setBusy]     = useState(false)

  const handle = e => setForm(f => ({ ...f, [e.target.name]: e.target.value }))

  const submit = async e => {
    e.preventDefault(); setError(''); setBusy(true)
    try {
      await api.post('/auth/register', form)
      setSuccess(true)
      setTimeout(() => navigate('/login'), 2200)
    } catch(err) { setError(errorText(err.response?.data?.detail)) }
    finally { setBusy(false) }
  }

  if (success) return (
    <div className="min-h-screen bg-ink-950 flex items-center justify-center px-6">
      <div className="text-center fade-up">
        <div className="w-14 h-14 rounded-2xl bg-sapphire-600/15 border border-sapphire-600/25 flex items-center justify-center mx-auto mb-5">
          <CheckCircle2 size={24} className="text-sapphire-400" />
        </div>
        <h2 className="font-bold text-xl text-white mb-2 tracking-tight">Kayıt Başarılı</h2>
        <p className="text-slate-500 text-sm">CKKS anahtarlarınız oluşturuldu. Giriş sayfasına yönlendiriliyorsunuz…</p>
      </div>
    </div>
  )

  return (
    <div className="min-h-screen bg-ink-950 flex">
      {/* Left */}
      <div className="hidden lg:flex lg:w-5/12 relative bg-ink-900 border-r border-white/5 items-center justify-center p-16 overflow-hidden">
        <div className="absolute inset-0 bg-grid-fine bg-grid-fine opacity-100" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 bg-sapphire-600/8 rounded-full blur-3xl" />
        <div className="relative text-center">
          <div className="w-14 h-14 rounded-2xl bg-sapphire-600/15 border border-sapphire-600/25 flex items-center justify-center mx-auto mb-6">
            <Database size={24} className="text-sapphire-400" />
          </div>
          <h2 className="font-bold text-xl text-white mb-2 tracking-tight">CipherMarket'e Katılın</h2>
          <p className="text-slate-500 text-sm leading-relaxed max-w-xs">Kayıt sırasında kurumunuza özel CKKS anahtar çifti otomatik oluşturulur.</p>
          <div className="mt-8 space-y-2 text-left">
            {['Mükerrer kayıt koruması','Kurum bazlı CKKS anahtarı','Sayılar DB’de ciphertext','Açık demo güven sınırları'].map(t => (
              <div key={t} className="flex items-center gap-2 text-xs text-slate-500">
                <div className="w-1 h-1 rounded-full bg-sapphire-400 flex-shrink-0" />
                {t}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right */}
      <div className="flex-1 flex items-center justify-center px-6 py-12 overflow-y-auto">
        <div className="w-full max-w-sm fade-up">
          <Link to="/" className="flex items-center gap-2 mb-10 lg:hidden">
            <div className="w-6 h-6 rounded-lg bg-sapphire-600 flex items-center justify-center">
              <Database size={12} className="text-white" />
            </div>
            <span className="font-semibold text-white text-sm">CipherMarket</span>
          </Link>

          <div className="mb-7">
            <h1 className="font-bold text-2xl text-white mb-1 tracking-tight">Kurumu Kaydet</h1>
            <p className="text-slate-500 text-sm">Tüm alanları eksiksiz doldurun</p>
          </div>

          {error && (
            <div className="mb-5 flex items-center gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/15 text-red-400 text-sm">
              <AlertCircle size={14} className="flex-shrink-0" /> {error}
            </div>
          )}

          <form onSubmit={submit} className="space-y-3.5">
            <div>
              <label className="block text-xs text-slate-500 mb-1.5 uppercase tracking-wider">Kurum / Şirket Adı</label>
              <input name="name" value={form.name} onChange={handle} required placeholder="ABC Ticaret A.Ş."
                className="input w-full px-4 py-2.5" />
            </div>
            <div>
              <label className="block text-xs text-slate-500 mb-1.5 uppercase tracking-wider">Kurumsal E-posta</label>
              <input name="email" type="email" value={form.email} onChange={handle} required placeholder="bilgi@abc.com.tr"
                className="input w-full px-4 py-2.5" />
            </div>
            <div>
              <label className="block text-xs text-slate-500 mb-1.5 uppercase tracking-wider">Vergi Numarası</label>
              <input name="tax_number" value={form.tax_number} onChange={handle} required placeholder="10 veya 11 haneli" maxLength={11}
                className="input w-full px-4 py-2.5 font-mono" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-slate-500 mb-1.5 uppercase tracking-wider">Sektör</label>
                <select name="sector" value={form.sector} onChange={handle} required className="input w-full px-3 py-2.5">
                  <option value="">Seçin</option>
                  {SECTORS.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs text-slate-500 mb-1.5 uppercase tracking-wider">Şehir</label>
                <select name="city" value={form.city} onChange={handle} required className="input w-full px-3 py-2.5">
                  <option value="">Seçin</option>
                  {CITIES.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
            </div>
            <div>
              <label className="block text-xs text-slate-500 mb-1.5 uppercase tracking-wider">Şifre</label>
              <div className="relative">
                <input name="password" type={show ? 'text' : 'password'} value={form.password} onChange={handle} required
                  placeholder="En az 8 karakter" className="input w-full px-4 py-2.5 pr-10" />
                <button type="button" onClick={() => setShow(s => !s)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-600 hover:text-slate-400 transition-colors">
                  {show ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </div>
            <button type="submit" disabled={busy} className="btn-primary w-full py-2.5 text-sm mt-1">
              {busy ? (
                <span className="flex items-center justify-center gap-2">
                  <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Kayıt oluşturuluyor…
                </span>
              ) : 'Kurumu Kaydet'}
            </button>
          </form>

          <p className="mt-6 text-center text-sm text-slate-600">
            Zaten hesabınız var mı?{' '}
            <Link to="/login" className="text-sapphire-400 hover:text-sapphire-300 font-medium transition-colors">
              Giriş yapın
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}
