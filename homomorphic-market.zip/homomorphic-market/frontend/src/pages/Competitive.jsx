import { useEffect, useMemo, useState } from 'react'
import { AlertCircle, CheckCircle2, Filter, Lock, RefreshCw, Shield, TrendingUp, Trophy } from 'lucide-react'
import {
  Bar, BarChart, CartesianGrid, Cell, Legend, Line, LineChart,
  ResponsiveContainer, Tooltip, XAxis, YAxis
} from 'recharts'
import api from '../utils/api.js'

const fmt = n => n == null ? 'Şifreli' : new Intl.NumberFormat('tr-TR', {
  style: 'currency',
  currency: 'TRY',
  maximumFractionDigits: 0,
}).format(n)
const fmtN = n => n == null ? 'Şifreli' : new Intl.NumberFormat('tr-TR').format(n)
const MONTH_NAMES = ['', 'Oca', 'Şub', 'Mar', 'Nis', 'May', 'Haz', 'Tem', 'Ağu', 'Eyl', 'Eki', 'Kas', 'Ara']
const SELF_COLOR = '#25a068'
const RIVAL_COLORS = ['#60a5fa', '#f59e0b', '#f87171', '#a78bfa', '#34d399', '#fb923c']

const TrendTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-ink-800 border border-white/10 rounded-xl p-3 text-xs shadow-xl">
      <p className="text-slate-400 mb-2">{label}</p>
      {payload.map((p, i) => (
        <div key={i} className="flex items-center gap-2 mb-1">
          <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: p.stroke }} />
          {p.value != null
            ? <span style={{ color: p.stroke }}>{p.name}: {fmt(p.value)}</span>
            : <span className="text-slate-500 font-mono">{p.name}: •••••• (şifreli)</span>}
        </div>
      ))}
    </div>
  )
}

export default function Competitive() {
  const [data, setData] = useState(null)
  const [proof, setProof] = useState(null)
  const [loading, setLoading] = useState(true)
  const [tab, setTab] = useState('ranking')
  const [city, setCity] = useState('')

  const load = async (nextCity = city) => {
    setLoading(true)
    try {
      const suffix = nextCity ? `?city=${encodeURIComponent(nextCity)}` : ''
      const [c, p] = await Promise.all([
        api.get(`/competitive/sector-comparison${suffix}`),
        api.get('/competitive/he-check'),
      ])
      setData(c.data)
      setProof(p.data)
      if (!nextCity && c.data?.selected_city) setCity(c.data.selected_city)
    } catch (e) {
      console.error(e)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load('') }, []) // eslint-disable-line

  const results = data?.results || []
  const scopeLabel = data?.selected_city === 'all' ? 'Tüm iller' : data?.selected_city

  const rankChartData = useMemo(() => [...results]
    .filter(r => r.rank)
    .sort((a, b) => a.rank - b.rank)
    .map((r, i) => ({
      name: r.display_name,
      score: r.ranking_score || 0,
      rank: r.rank,
      isSelf: r.is_self,
      color: r.is_self ? SELF_COLOR : RIVAL_COLORS[i % RIVAL_COLORS.length],
    })), [results])

  const trendData = useMemo(() => {
    const allMonths = [...new Set(
      results.flatMap(r => (r.monthly_trend || []).map(m => `${m.year}-${String(m.month).padStart(2, '0')}`))
    )].sort()

    return allMonths.map(ym => {
      const [y, m] = ym.split('-')
      const row = { name: `${MONTH_NAMES[parseInt(m)]}/${y.slice(2)}` }
      results.forEach(r => {
        const match = (r.monthly_trend || []).find(t => t.year === parseInt(y) && t.month === parseInt(m))
        row[r.display_name] = r.is_self && match ? match.revenue : null
      })
      return row
    })
  }, [results])

  if (loading) return (
    <div className="flex flex-col items-center justify-center h-64">
      <div className="w-8 h-8 border-2 border-sapphire-500 border-t-transparent rounded-full animate-spin mb-3" />
      <p className="text-slate-400 text-sm">Şifreli veriler karşılaştırılıyor...</p>
    </div>
  )

  return (
    <div className="space-y-6 fade-in">
      <div className="grid md:grid-cols-3 gap-4">
        <div className="p-4 rounded-2xl bg-sapphire-500/10 border border-sapphire-500/20">
          <div className="flex items-center gap-2 mb-1">
            <Trophy size={14} className="text-sapphire-400" />
            <span className="text-xs text-sapphire-400 font-medium uppercase tracking-wider">Sıralama</span>
          </div>
          <div className="font-display text-3xl font-700 text-white">
            {data?.ranking_available ? `#${data?.my_rank || '-'}` : 'Yok'}
            <span className="text-base text-slate-400 font-normal"> / {results.length}</span>
          </div>
          <p className="text-xs text-slate-500 mt-1">{data?.sector} · {scopeLabel}</p>
          {data?.trusted_aggregation_demo && <p className="text-xs text-amber-400 mt-1">Sunucuda çözümleme kullanan demo sıralaması</p>}
        </div>
        <div className="p-4 rounded-2xl bg-ink-900 border border-white/6">
          <div className="flex items-center gap-2 mb-1">
            <Shield size={14} className="text-slate-400" />
            <span className="text-xs text-slate-400 font-medium uppercase tracking-wider">Rakip Sayısı</span>
          </div>
          <div className="font-display text-3xl font-700 text-white">{data?.total_competitors || 0}</div>
          <p className="text-xs text-slate-500 mt-1">Yalnızca kendi sektörünüz</p>
        </div>
        <div className="p-4 rounded-2xl bg-ink-900 border border-white/6">
          <div className="flex items-center gap-2 mb-1">
            <Lock size={14} className="text-slate-400" />
            <span className="text-xs text-slate-400 font-medium uppercase tracking-wider">Şifreleme</span>
          </div>
          <div className="font-display text-lg font-700 text-white">CKKS</div>
          <p className="text-xs text-slate-500 mt-1">TenSEAL · merkezi sunucu güven sınırı</p>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row lg:items-center gap-3 justify-between">
        <div className="flex gap-1 p-1 bg-ink-800 rounded-xl w-fit">
          {[
            ['ranking', 'Sıralama'],
            ['chart', 'Sıralama Grafiği'],
            ['trend', 'Trend'],
            ['proof', 'HE İşlem Kontrolü'],
          ].map(([k, l]) => (
            <button key={k} onClick={() => setTab(k)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${tab === k ? 'bg-sapphire-500 text-white' : 'text-slate-400 hover:text-white'}`}>
              {l}
            </button>
          ))}
        </div>

        <label className="flex items-center gap-2 text-xs text-slate-500">
          <Filter size={13} />
          İl filtresi
          <select
            value={city}
            onChange={(e) => {
              setCity(e.target.value)
              load(e.target.value)
            }}
            className="px-3 py-2 bg-ink-800 border border-white/10 rounded-lg text-sm text-white outline-none focus:border-sapphire-500/60"
          >
            <option value="all">Tüm iller</option>
            {(data?.available_cities || []).map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </label>
      </div>

      {tab === 'ranking' && (
        <div className="bg-ink-900 border border-white/6 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-display font-600 text-white text-base">
              {data?.sector} - {scopeLabel} Güvenli Karşılaştırma
            </h3>
            <span className="text-xs font-mono text-sapphire-400/70 flex items-center gap-1">
              <AlertCircle size={10} /> Merkezi sunucu demo sıralaması
            </span>
          </div>

          <div className="grid md:grid-cols-3 gap-2 mb-5">
            {[
              ['Sizin Verileriniz', 'Gelir ve adet tam gösterilir', 'text-sapphire-400', 'border-sapphire-500/20', 'bg-sapphire-500/5'],
              ['Paylaşılan kayıtlar', 'Sıralama sırasında sunucu tarafından çözülür', 'text-amber-300', 'border-amber-500/20', 'bg-amber-500/5'],
              ['Sektör Kuralı', 'Sadece kendi sektörünüz karşılaştırılır', 'text-slate-300', 'border-white/6', 'bg-ink-800/40'],
            ].map(([t, d, tc, bc, bg]) => (
              <div key={t} className={`p-3 rounded-xl border ${bc} ${bg} text-xs`}>
                <p className={`font-medium mb-0.5 ${tc}`}>{t}</p>
                <p className="text-slate-500">{d}</p>
              </div>
            ))}
          </div>

          {results.length === 0 ? (
            <div className="text-center py-12 text-slate-500 text-sm">
              <AlertCircle size={24} className="mx-auto mb-2 opacity-50" />
              Bu filtrede karşılaştırılacak kurum bulunamadı.
            </div>
          ) : (
            <div className="space-y-3">
              {results.map(r => (
                <div key={r.institution_id}
                  className={`flex items-center gap-4 p-4 rounded-xl border transition-colors ${
                    r.is_self ? 'bg-sapphire-500/10 border-sapphire-500/30' : 'bg-ink-800/40 border-white/6'
                  }`}>
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center font-display font-700 text-sm flex-shrink-0 ${
                    r.rank === 1 ? 'bg-amber-500/20 text-amber-500' :
                    r.is_self ? 'bg-sapphire-500 text-white' : 'bg-ink-700 text-slate-400'
                  }`}>
                    {r.rank ? `#${r.rank}` : <Lock size={13} />}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm text-white font-medium">{r.display_name}</span>
                      {r.is_self && <span className="text-xs px-1.5 py-0.5 rounded bg-sapphire-500/20 text-sapphire-400">Siz</span>}
                      <span className="text-xs px-1.5 py-0.5 rounded bg-ink-700 text-slate-500 font-mono flex items-center gap-1">
                        <Lock size={8} /> {r.is_self ? 'Sizin veriniz' : 'Şifreli'}
                      </span>
                    </div>
                    <div className="text-xs text-slate-500 mt-0.5 flex flex-wrap gap-3">
                      <span>İl: {r.city}</span>
                      <span>Top kategori: {r.top_category}</span>
                      {r.rank && <span className="font-mono text-slate-600">Endeks {r.ranking_score}/100</span>}
                      {r.ciphertext_eval_ms > 0 && <span className="font-mono text-slate-600">ciphertext toplama: {r.ciphertext_eval_ms} ms</span>}
                    </div>
                  </div>

                  <div className="text-right flex-shrink-0">
                    {r.is_self ? (
                      <>
                        <div className="font-mono text-sm font-600 text-sapphire-400">{fmt(r.total_revenue)}</div>
                        <div className="text-xs text-slate-500">{fmtN(r.total_quantity)} adet</div>
                      </>
                    ) : (
                      <>
                        <div className="flex items-center gap-1.5 justify-end">
                          <Lock size={11} className="text-slate-600" />
                          <span className="font-mono text-sm text-slate-600 tracking-widest">••••••</span>
                        </div>
                        <div className="text-xs text-slate-700 font-mono">{r.shared_record_count || 0} kayıt</div>
                      </>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {tab === 'chart' && (
        <div className="bg-ink-900 border border-white/6 rounded-2xl p-6">
          <h3 className="font-display font-600 text-white text-base mb-2">Sunucu Demo Sıralama Grafiği</h3>
          <p className="text-xs text-slate-500 mb-5 flex items-center gap-1">
            <AlertCircle size={10} /> Sıralama, sunucuda çözülen paylaşımlı gelirlerden türetilir; bu bir HE sıralama protokolü değildir.
          </p>

          {rankChartData.length === 0 ? (
            <div className="text-center py-12 text-slate-500 text-sm">
              <AlertCircle size={20} className="mx-auto mb-2 opacity-50" />
              Veri yok
            </div>
          ) : (
            <>
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={rankChartData} layout="vertical" barGap={4}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(37,99,235,0.10)" horizontal={false} />
                  <XAxis type="number" domain={[0, 100]} tick={{ fill: '#64748b', fontSize: 10 }} />
                  <YAxis type="category" dataKey="name" width={120} tick={{ fill: '#48627f', fontSize: 10 }} />
                  <Tooltip content={({ active, payload }) => {
                    if (!active || !payload?.length) return null
                    const r = payload[0].payload
                    return (
                      <div className="bg-ink-800 border border-white/10 rounded-xl p-3 text-xs shadow-xl">
                        <p className="text-slate-400 mb-1 font-medium">{r.name}</p>
                        <p className="font-mono text-sapphire-400">Sıra: #{r.rank}</p>
                        <p className="font-mono text-slate-500">Endeks: {r.score}/100</p>
                        {!r.isSelf && <p className="font-mono text-slate-500">Gerçek tutar: ••••••</p>}
                      </div>
                    )
                  }} />
                  <Bar dataKey="score" radius={[0, 6, 6, 0]} name="Gizli Sıralama Endeksi">
                    {rankChartData.map((entry, i) => (
                      <Cell key={i} fill={entry.color} fillOpacity={entry.isSelf ? 1 : 0.55} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>

              <div className="mt-5 p-3 rounded-xl bg-ink-800/40 border border-white/6 text-xs">
                <p className="text-slate-500 mb-2">Grafik Açıklaması</p>
                <p className="text-slate-400">
                  Sunucu rakiplerin paylaşıma açılmış gelir toplamlarını çözer ve sıra/endeks üretir. Ham tutarlar
                  ekranda maskeli olsa da sıralama göreli gelir bilgisini sızdırabilir. Uygulama sunucusu bu demo için
                  güvenilir kabul edilir; gizli kurumlar arası sıralama protokolü kullanılmıyor.
                </p>
              </div>
            </>
          )}
        </div>
      )}

      {tab === 'trend' && (
        <div className="bg-ink-900 border border-white/6 rounded-2xl p-6">
          <h3 className="font-display font-600 text-white text-base mb-2">Aylık Gelir Trend Karşılaştırması</h3>
          <div className="mb-5 flex items-center gap-2 p-3 rounded-lg bg-ink-800/50 border border-white/6 text-xs text-slate-400">
            <Lock size={12} className="text-sapphire-400 flex-shrink-0" />
            Rakip gelir verileri maskeli kalır; grafikte yalnızca kendi gelir trendiniz sayısal gösterilir.
          </div>

          {results.length < 2 ? (
            <div className="text-center py-12 text-slate-500 text-sm">
              <TrendingUp size={24} className="mx-auto mb-2 opacity-50" />
              Karşılaştırma için en az 2 kurum gerekli.
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={trendData}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(37,99,235,0.10)" />
                <XAxis dataKey="name" tick={{ fill: '#64748b', fontSize: 10 }} />
                <YAxis tickFormatter={v => v > 0 ? `${(v / 1000).toFixed(0)}K` : ''} tick={{ fill: '#64748b', fontSize: 10 }} />
                <Tooltip content={<TrendTooltip />} />
                <Legend wrapperStyle={{ fontSize: 11, color: '#94a3b8' }} />
                {results.map((r, i) => (
                  <Line key={r.institution_id}
                    type="monotone"
                    dataKey={r.display_name}
                    stroke={r.is_self ? SELF_COLOR : RIVAL_COLORS[(i - 1) % RIVAL_COLORS.length]}
                    strokeWidth={r.is_self ? 2.5 : 1.5}
                    strokeDasharray={r.is_self ? undefined : '6 3'}
                    dot={r.is_self ? { r: 3, fill: SELF_COLOR } : false}
                    connectNulls={false}
                  />
                ))}
              </LineChart>
            </ResponsiveContainer>
          )}
        </div>
      )}

      {tab === 'proof' && proof && (
        <div className="bg-ink-900 border border-white/6 rounded-2xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-display font-600 text-white text-base">Homomorfik İşlem Kontrolü</h3>
            <span className={`flex items-center gap-1 text-xs px-2 py-1 rounded-lg font-mono ${
              proof.verification === 'passed' ? 'bg-sapphire-500/15 text-sapphire-400' : 'bg-amber-500/15 text-amber-400'
            }`}>
              {proof.verification === 'passed' ? <CheckCircle2 size={12} /> : <AlertCircle size={12} />}
              {proof.verification === 'passed' ? 'Doğrulandı' : proof.verification}
            </span>
          </div>

          <div className="grid md:grid-cols-3 gap-3">
            {[
              ['Şema', proof.scheme],
              ['Polinom Derecesi', proof.poly_modulus_degree],
              ['Global Scale', proof.global_scale],
            ].map(([k, v]) => (
              <div key={k} className="p-3 rounded-xl bg-ink-800/50 border border-white/6">
                <p className="text-xs text-slate-500 mb-0.5">{k}</p>
                <p className="font-mono text-sm text-white">{v}</p>
              </div>
            ))}
          </div>

          <p className="text-xs text-slate-400 p-3 rounded-xl bg-sapphire-500/5 border border-sapphire-500/10">{proof.message}</p>

          {proof.samples?.length > 0 ? (
            <div className="space-y-3">
              <p className="text-xs text-slate-500 uppercase tracking-wider font-medium">Örnek Kayıt Doğrulamaları</p>
              {proof.samples.map((s, i) => (
                <div key={i} className="p-4 rounded-xl bg-ink-800/40 border border-white/6 text-xs">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-white font-medium">{s.product}</span>
                    <span className={`flex items-center gap-1 px-1.5 py-0.5 rounded font-mono ${s.values_match ? 'bg-sapphire-500/15 text-sapphire-400' : 'bg-red-500/15 text-red-400'}`}>
                      {s.values_match ? <CheckCircle2 size={10} /> : <AlertCircle size={10} />}
                      {s.values_match ? 'Eşleşti' : 'Hata'}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                    <div><p className="text-slate-500">Sayısal DB alanı</p><p className="font-mono text-sapphire-300">Ciphertext</p></div>
                    <div><p className="text-slate-500">Sunucuda Çözülen</p><p className="font-mono text-sapphire-300">{fmt(s.decrypted_by_server_for_owner)}</p></div>
                    <div><p className="text-slate-500">HE İşlem Sonucu</p><p className="font-mono text-sapphire-300">{fmt(s.he_operation_result)}</p></div>
                    <div><p className="text-slate-500">Şifreli Boyut</p><p className="font-mono text-slate-300">{s.encrypted_size_bytes} byte ({s.ciphertext_to_float_ratio}× 8 bayt karşılaştırması)</p></div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-slate-500 text-sm text-center py-4">Önce Veri Girişi sekmesinden veri ekleyin</p>
          )}
        </div>
      )}

      <div className="flex justify-end">
        <button onClick={() => load(city)} className="flex items-center gap-2 px-4 py-2 text-xs text-slate-400 hover:text-white border border-white/10 hover:border-white/20 rounded-lg transition-colors">
          <RefreshCw size={12} /> Yenile
        </button>
      </div>
    </div>
  )
}
