/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: {
          950: '#eef8ff',
          900: '#f5fbff',
          800: '#e8f5ff',
          700: '#d9ecfb',
          600: '#bedaf0',
          500: '#8fb8d7',
        },
        sapphire: {
          700: '#1e40af',
          600: '#2563eb',
          500: '#3b82f6',
          400: '#60a5fa',
          300: '#93c5fd',
          200: '#bfdbfe',
        },
        gold: {
          600: '#b45309',
          500: '#d97706',
          400: '#f59e0b',
          300: '#fbbf24',
          200: '#fde68a',
        },
      },
      fontFamily: {
        display: ['"Inter"', 'system-ui', 'sans-serif'],
        body:    ['"Inter"', 'system-ui', 'sans-serif'],
        mono:    ['"JetBrains Mono"', 'monospace'],
      },
      backgroundImage: {
        'grid-fine':  "linear-gradient(rgba(37,99,235,0.075) 1px,transparent 1px),linear-gradient(90deg,rgba(37,99,235,0.075) 1px,transparent 1px)",
        'hero-glow':  'radial-gradient(ellipse 70% 50% at 50% -5%,rgba(96,165,250,0.28),transparent)',
      },
      backgroundSize: { 'grid-fine': '28px 28px' },
      boxShadow: {
        card:       '0 12px 34px rgba(30,64,175,0.08),0 0 0 1px rgba(37,99,235,0.10)',
        'card-up':  '0 18px 42px rgba(30,64,175,0.12),0 0 0 1px rgba(37,99,235,0.18)',
        'glow-s':   '0 0 20px rgba(37,99,235,0.16)',
        'glow-g':   '0 0 20px rgba(245,158,11,0.13)',
      },
    },
  },
  plugins: [],
}
