# CipherMarket

CipherMarket, CKKS homomorfik şifrelemenin sayısal satış analitiğine nasıl eklenebileceğini gösteren eğitim ve araştırma amaçlı bir prototiptir. Sayısal satış alanlarını veritabanına yazmadan önce şifreler ve seçili toplamları TenSEAL ile ciphertext üzerinde hesaplar.

Bu proje üretim ortamında kullanılmaya hazır bir gizlilik platformu değildir. Kurumlar arası sıralama homomorfik olarak yapılmaz.

## Şifreleme modeli ve sınırlar

- Kayıt sırasında backend her kurum için ayrı bir CKKS context'i üretir.
- Satış girilirken backend sayıları açık biçimde alır; geliri, adedi ve birim fiyatı şifreledikten sonra veritabanına yazar.
- Ürün adı, kategori, satış tarihi, ay, yıl, bölge, kurum kimliği ve paylaşım bilgisi açık metadata olarak saklanır.
- Kurum sahibine ait bazı toplamlar ciphertext üzerinde hesaplanır. Backend, sonuçları kuruma ait secret context ile çözüp sahibine döndürür.
- Kurumların secret context'leri veritabanında `SECRET_KEY`'den türetilen bir anahtarla şifrelenerek saklanır. Uygulama sunucusunu ve yapılandırmasını kontrol eden biri bu verileri çözebilir. Bu, sunucu tarafı anahtar korumasıdır; uçtan uca şifreleme veya sunucu işletmecisine karşı koruma değildir.
- Rakip sıralaması, paylaşıma açılmış rakip kayıtlarını uygulama sunucusunda çözüp gelir toplamına göre sıra üretir. API yanıtı rakip tutarlarını gizler; ancak sunucu tutarları görür ve sıra/endeks göreli gelir bilgisini açığa çıkarabilir. Bu, homomorfik sıralama ya da gizli toplulaştırma değildir. Üretimde ayrı tasarlanmış ve gözden geçirilmiş MPC, çoklu anahtarlı HE veya güvenilir toplayıcı protokolü gerekir.
- CKKS yaklaşık sayısal aritmetik kullanır. Ufak sayısal sapmalar olabilir; sonuçlar kesin muhasebe kaydı olarak kullanılmamalıdır.

Bu prototip, ciphertext işlemlerinin analitik akışındaki yerini incelemek için tasarlanmıştır. Gerçek işletme verilerini yüklemeyin ve uygulamayı herkese açık internete açmayın.

## Teknolojiler

- FastAPI, SQLAlchemy, PostgreSQL
- TenSEAL 0.3.18 / CKKS
- React 18, Vite, Nginx
- Docker Compose

## Yerelde çalıştırma

Gereksinim: Docker Desktop ve Docker Compose.

```powershell
Copy-Item .env.example .env
docker compose up --build
```

Arayüz: <http://localhost:3000>  
API dokümantasyonu: <http://localhost:8000/docs>

Veritabanı portu ana makineye açılmaz. Web ve API portları varsayılan olarak yalnızca yerel makineye (`127.0.0.1`) bağlanır.

Depodaki `.env.example` yalnızca yerel demo içindir. İnternete açık bir dağıtımda `ENVIRONMENT=production` kullanın, benzersiz sırları bir sır kasasından üretin ve `CORS_ORIGINS` için yalnızca izin verilen tam origin adreslerini tanımlayın. `POSTGRES_PASSWORD`, Compose'un `DATABASE_URL` oluşturması için URL uyumlu karakterlerden oluşmalıdır.

## CSV biçimi

Gerekli başlıklar: `product_name,category,quantity_sold,unit_price,sale_date`. `region` isteğe bağlıdır. Tarih biçimi `YYYY-MM-DD` olmalıdır. Yükleme sınırı 2 MB ve 5.000 satırdır.

## Depo ve veritabanı notları

- `.env` Git tarafından yok sayılır. Gerçek sırları Git'e veya herkese açık hata kayıtlarına eklemeyin.
- `.env.example` içindeki değerler dağıtım için kullanılmamalıdır.
- Backend, temiz bir demo veritabanında tabloları başlangıçta oluşturur. Üretim tipi veritabanı migration'ları, hesap kurtarma ve istek hız sınırlama akışları bu prototipte yoktur.
- Eski sürüm veritabanlarında eski açık sayı sütunları bulunabilir. `create_all` eski sütunları silmez veya veriyi dönüştürmez. Önce veritabanını yedekleyin; eski anahtarları açmak için önceki `SECRET_KEY` değerini kullanın. Şema/veri migration'ı yapmadan eski veritabanına bağlamayın.
- Yeniden kullanım ve katkı koşulları belirtilmediği için lisans eklenmemiştir. Depoyu yayımlamadan önce uygun bir lisans seçin.

## Proje yapısı

```text
backend/app/api/           FastAPI uç noktaları
backend/app/core/          Ayarlar, veritabanı ve kimlik doğrulama
backend/app/models/        SQLAlchemy modelleri
backend/app/services/      CKKS yardımcıları ve sentetik veri üreticisi
frontend/src/pages/        React ekranları
docker-compose.yml         Yerel geliştirme servisleri
```

Güvenlik açığı bildirimlerinde gerçek kimlik bilgilerini veya kişisel verileri herkese açık GitHub issue'larına eklemeyin. Depo yöneticisine özel kanaldan bildirin; depoyu yayımlamadan önce özel bildirim yöntemi tanımlayın.
